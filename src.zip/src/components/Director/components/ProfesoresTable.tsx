import { useMemo } from 'react'
import { ArrowRight, Megaphone } from 'lucide-react'
import type { StudentProfile } from '../DirectorTypes'
import { scoreColor } from '../DirectorTypes'
import styles from './ProfesoresTable.module.css'

function scoreColor(s: number | null | undefined): string {
  if (s == null) return '#6B7280'
  if (s >= 80) return '#059669'
  if (s >= 60) return '#0891B2'
  if (s >= 40) return '#B45309'
  return '#DC2626'
}

// ── ProfesoresTable ────────────────────────────────────────────────────────
function ProfesoresTable({ staffProfiles, stats, onProfesorClick }: {
  staffProfiles:   StudentProfile[]
  stats:           Stats
  onProfesorClick: (p: StudentProfile) => void
}) {
  const profesores = useMemo(() => {
    const profStats = stats.bySubject.flatMap(sub => sub.profesores.map(p => ({ ...p, subjectName: sub.name, subjectColor: sub.color })))
    return staffProfiles.filter(p => p.role === 'profesor').map(p => ({ ...p, stats: profStats.find(s => s.id === p.id) ?? null }))
  }, [staffProfiles, stats])

  if (!profesores.length) return <p className={styles.empty}>No hay profesores registrados en esta academia.</p>

  const now    = new Date()
  const act    = stats.profesorActivity
  const fmtDias = (iso: string) => {
    const dias = Math.floor((now.getTime() - new Date(iso).getTime()) / 86400000)
    if (dias === 0) return 'Hoy'
    if (dias === 1) return 'Ayer'
    if (dias < 30)  return `Hace ${dias}d`
    return `Hace ${Math.round(dias/30)}m`
  }

  return (
    <div className={styles.profesoresGrid}>
      {profesores.map(p => {
        const ext        = p.extended ?? {}
        const nombre     = String(ext.full_name ?? '') || p.username
        const lastAviso  = act?.lastAvisoByProfesor[p.id]
        const totalAvisos= act?.totalAvisosByProfesor[p.id] ?? 0
        const nAlumnos   = p.stats?.alumnos ?? 0
        const nota       = p.stats?.notaMedia ?? null
        const sinActividad = lastAviso
          ? Math.floor((now.getTime() - new Date(lastAviso.created_at).getTime()) / 86400000) > 14
          : true

        return (
          <div key={p.id} className={styles.profeCard}
            style={{
              borderTop: `3px solid ${sinActividad ? '#DC2626' : '#7C3AED'}`,
              boxShadow: sinActividad
                ? '0 4px 16px rgba(220,38,38,0.1)'
                : '0 4px 16px rgba(124,58,237,0.1)',
            }}
            onClick={() => onProfesorClick(p)}>

            {/* Cabecera */}
            <div className={styles.profeCardHead}>
              <div className={styles.profeAvatar} style={{
                background: sinActividad ? 'rgba(220,38,38,0.1)' : 'rgba(124,58,237,0.1)',
                color:      sinActividad ? '#DC2626' : '#7C3AED',
              }}>
                {nombre[0]!.toUpperCase()}
              </div>
              <div className={styles.profeInfo}>
                <span className={styles.profeNombre}>{nombre}</span>
                {ext.full_name && <span className={styles.profeUsername}>@{p.username}</span>}
              </div>
              {sinActividad && (
                <span className={styles.profeAlerta}>Sin actividad</span>
              )}
            </div>

            {/* Asignatura */}
            {p.stats && (
              <div className={styles.profeAsig}>
                <div className={styles.alumnoDot} style={{background: p.stats.subjectColor}}/>
                <span>{p.stats.subjectName}</span>
              </div>
            )}

            {/* KPIs */}
            <div className={styles.profeKpis}>
              <div className={styles.profeKpi}>
                <span className={styles.profeKpiVal}>{nAlumnos}</span>
                <span className={styles.profeKpiLabel}>Alumnos</span>
              </div>
              <div className={styles.profeKpi}>
                <span className={styles.profeKpiVal} style={{color: scoreColor(nota)}}>{nota !== null ? `${nota}%` : '—'}</span>
                <span className={styles.profeKpiLabel}>Nota media</span>
              </div>
              <div className={styles.profeKpi}>
                <span className={styles.profeKpiVal}>{totalAvisos}</span>
                <span className={styles.profeKpiLabel}>Avisos</span>
              </div>
            </div>

            {/* Último aviso */}
            <div className={styles.profeUltimoAviso}>
              <Megaphone size={11} style={{flexShrink:0, color: sinActividad ? '#DC2626' : 'var(--ink-subtle)'}}/>
              {lastAviso ? (
                <span style={{color: sinActividad ? '#DC2626' : 'var(--ink-muted)'}}>
                  {fmtDias(lastAviso.created_at)} — <em>{lastAviso.title.slice(0,40)}{lastAviso.title.length>40?'…':''}</em>
                </span>
              ) : (
                <span style={{color:'#DC2626'}}>Sin avisos publicados</span>
              )}
            </div>
          </div>
        )
      })}
    </div>
  )
}

// ── RentabilidadCard ───────────────────────────────────────────────────────
function RentabilidadCard({ stats, studentProfiles }: { stats: Stats; studentProfiles: StudentProfile[] }) {
  const preciosReales = studentProfiles.filter(p => p.extended?.monthly_price).map(p => parseFloat(String(p.extended!.monthly_price)))
  const mrrReal   = preciosReales.length > 0 ? preciosReales.reduce((a, b) => a + b, 0) : null
  const sinPrecio = studentProfiles.filter(p => !p.extended?.monthly_price).length
  const [precioBase,  setPrecioBase]  = useState('')
  const [editando,    setEditando]    = useState(false)
  const [inputPrecio, setInputPrecio] = useState('')
  const mrr       = mrrReal ?? (precioBase ? stats.totalAlumnos * parseFloat(precioBase) : null)
  const mrrRiesgo = precioBase ? stats.totalEnRiesgo * parseFloat(precioBase) : null

  return (
    <div className={styles.rentCard}>
      <div className={styles.rentHeader}>
        <h3 className={styles.rentTitle}><Euro size={14} /> Rentabilidad estimada</h3>
        <button className={styles.rentEditBtn} onClick={() => { setEditando(v => !v); setInputPrecio(precioBase) }}>
          {editando ? 'Cancelar' : '+ Precio base'}
        </button>
      </div>
      {mrrReal !== null && (
        <div className={styles.rentInfo}>
          <strong>{mrrReal.toLocaleString('es-ES', { minimumFractionDigits: 0 })} €/mes</strong> calculados desde los precios individuales de {preciosReales.length} alumno{preciosReales.length !== 1 ? 's' : ''}.
          {sinPrecio > 0 && ` ${sinPrecio} alumno${sinPrecio !== 1 ? 's' : ''} sin precio asignado.`}
        </div>
      )}
      {editando && (
        <div className={styles.rentForm}>
          <span className={styles.rentFormLabel}>Precio base para alumnos sin precio individual (€/mes)</span>
          <input type="number" className={styles.rentInput} value={inputPrecio} onChange={e => setInputPrecio(e.target.value)} placeholder="ej: 89" min="0" autoFocus />
          <button className={styles.rentGuardar} onClick={() => { setPrecioBase(inputPrecio); setEditando(false) }}>Aplicar</button>
        </div>
      )}
      {mrr !== null && (
        <div className={styles.rentKpis}>
          <div className={styles.rentKpi}><span className={styles.rentKpiVal} style={{ color: '#059669' }}>{mrr.toLocaleString('es-ES')} €</span><span className={styles.rentKpiLabel}>MRR</span></div>
          <div className={styles.rentKpi}><span className={styles.rentKpiVal}>{stats.totalAlumnos}</span><span className={styles.rentKpiLabel}>Alumnos</span></div>
          <div className={styles.rentKpi}>
            <span className={styles.rentKpiVal} style={{ color: '#DC2626' }}>
              -{((mrrRiesgo ?? 0) + (sinPrecio > 0 && precioBase ? sinPrecio * parseFloat(precioBase) : 0)).toLocaleString('es-ES')} €
            </span>
            <span className={styles.rentKpiLabel}>En riesgo</span>
          </div>
          <div className={styles.rentKpi}><span className={styles.rentKpiVal} style={{ color: '#059669' }}>{(mrr * 12).toLocaleString('es-ES')} €</span><span className={styles.rentKpiLabel}>ARR estimado</span></div>
        </div>
      )}
      {mrr === null && !editando && <p className={styles.rentSub}>Asigna precios individuales desde el perfil de cada alumno, o introduce un precio base para todos.</p>}
    </div>
  )
}

// ── ComunicacionPanel ────────────────────────────────────────────────────────
function ComunicacionPanel({ currentUser, profiles, mensajes, onDelete }: {

export { ProfesoresTable }
