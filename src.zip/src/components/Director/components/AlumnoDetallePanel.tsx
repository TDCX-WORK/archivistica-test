import { useState } from 'react'
import { supabase } from '../../../../lib/supabase'
import {
  ArrowLeft, BookOpen, Calendar, Phone, Mail, MapPin,
  Target, Edit3, CheckCircle, Clock, Shield, AlertTriangle, Euro
} from 'lucide-react'
import type { StudentProfile, AlumnoDetalleForm } from '../DirectorTypes'
import { scoreColor, fmt, MASCOTAS } from '../DirectorTypes'
import styles from './AlumnoDetallePanel.module.css'

function InfoRow({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: string | null | undefined }) {
  if (!value) return null
  return (
    <div className={styles.infoRow}>
      <Icon size={14} className={styles.infoIcon} />
      <span className={styles.infoLabel}>{label}</span>
      <span className={styles.infoValue}>{value}</span>
    </div>
  )
}

}) {
  const preciosReales = studentProfiles.filter(p => p.extended?.monthly_price).map(p => parseFloat(String(p.extended!.monthly_price)))
  const mrr = preciosReales.length > 0 ? preciosReales.reduce((a, b) => a + b, 0) : null

  const cards = [
    { id:'overview',    label:'Actividad',    desc: stats.sesiones30d>0?`${stats.sesiones30d} sesiones este mes`:'Sin sesiones todavía',                                                      icon:TrendingUp,   color:'#0891B2', big:true,  isAsig:false, badge:null as number|null },
    { id:'alumnos',     label:'Alumnos',      desc: stats.totalAlumnos>0?`${stats.totalAlumnos} matriculados · ${stats.totalActivos} activos`:'Sin alumnos aún',                              icon:Users,        color:'#2563EB', big:false, isAsig:false, badge:null as number|null },
    { id:'alertas',     label:'Alertas',      desc: nAlertas>0?`${nAlertas} acción${nAlertas!==1?'es':''} pendiente${nAlertas!==1?'s':''}`:'Todo en orden',                                   icon:AlertTriangle,color:nAlertas>0?'#DC2626':'#059669', big:false, isAsig:false, badge:nAlertas>0?nAlertas:null as number|null },
    { id:'profesores',  label:'Profesores',   desc: stats.totalProfesores>0?`${stats.totalProfesores} profesor${stats.totalProfesores!==1?'es':''}`:'Sin profesores aún',                    icon:GraduationCap,color:'#7C3AED', big:false, isAsig:false, badge:null as number|null },
    { id:'finanzas',    label:'Finanzas',     desc: stats.finanzas ? `${new Intl.NumberFormat('es-ES',{style:'currency',currency:'EUR',maximumFractionDigits:0}).format(stats.finanzas.mrrAcademia)}/mes` : 'Ver ingresos', descExtra: null, icon:Euro, color:'#059669', big:false, isAsig:false, badge:null as number|null },
    { id:'comunicacion', label:'Comunicación', desc: nMensajes>0?`${nMensajes} mensaje${nMensajes!==1?'s':''} enviado${nMensajes!==1?'s':''}`:'Mensajes directos', descExtra: null, icon:MessageSquare, color:'#0891B2', big:false, isAsig:false, badge: nRespuestas > 0 ? nRespuestas : null as number|null },
    { id:'vencimientos', label:'Vencimientos', desc: (stats.totalPorExpirar>0?`${stats.totalPorExpirar} expiran pronto`:'Gestión de accesos'), descExtra: null, icon:Calendar, color:'#D97706', big:false, isAsig:false, badge: stats.totalPorExpirar>0?stats.totalPorExpirar:null as number|null },
    { id:'retencion',   label:'Retención',    desc: 'Permanencia y cohortes', descExtra: null, icon:TrendingUp, color:'#7C3AED', big:false, isAsig:false, badge:null as number|null },
    { id:'asignaturas', label:'Asignaturas',  desc: `${stats.bySubject?.length??0} asignatura${(stats.bySubject?.length??0)!==1?'s':''} activa${(stats.bySubject?.length??0)!==1?'s':''}`, icon:BookOpen,     color:'#D97706', big:false, isAsig:true,  badge:null as number|null },

  ]

  return (
    <div className={styles.bentoGrid}>
      {cards.map(card => {
        const Icon = card.icon, active = tab===card.id
        return (
          <button key={card.id}
            className={[styles.bentoCard, card.big?styles.bentoBig:'', active&&!card.isAsig?styles.bentoActive:'', card.isAsig?styles.bentoExam:''].join(' ')}
            style={{ ['--bento-color' as string]: card.color }}
            onClick={() => setTab(card.isAsig?'asignaturas':card.id)}>
            {card.big && !card.isAsig && <AnimatedGridPattern numSquares={18} maxOpacity={active?0.12:0.06} duration={4} color={card.color} lineColor={card.color+'20'} />}
            {!card.isAsig && <Ripple mainCircleSize={card.big?60:40} mainCircleOpacity={active?0.25:0.12} numCircles={card.big?5:3} color={card.color} duration={card.big?3:3.5} />}
            {card.isAsig ? (
              <div className={styles.bentoContent}>
                <div className={styles.bentoExamHeader}>
                  <div className={styles.bentoIconWrap} style={{ background:card.color+'18', color:card.color }}><Icon size={16} strokeWidth={1.8} /></div>
                  <span className={styles.bentoLabel}>{card.label}</span>
                </div>
                <AsignaturasCard stats={stats} />
              </div>
            ) : (
              <div className={styles.bentoContent}>
                <div className={styles.bentoIconWrap} style={{ background:card.color+'18', color:card.color }}><Icon size={card.big?20:16} strokeWidth={1.8} /></div>
                <div className={styles.bentoText}><span className={styles.bentoLabel}>{card.label}</span><span className={styles.bentoDesc}>{card.desc}</span></div>
                {card.badge!=null&&card.badge>0&&<span className={styles.bentoBadge} style={{ background:card.color }}>{card.badge}</span>}
              </div>
            )}
          </button>
        )
      })}
    </div>
  )
}

// ── Panel principal ────────────────────────────────────────────────────────
export default function DirectorPanel({ currentUser }: { currentUser: CurrentUser | null }) {

  const { stats, allProfiles, loading, error } = useDirector(currentUser)
  const { sent: dmSent, sendMessage: dmSend, deleteSentMessage: dmDelete } = useProfesorMessages(
    currentUser?.id, currentUser?.academy_id, currentUser?.subject_id
  )
  const { studentProfiles, staffProfiles, loading: loadingProfiles, updateStudentProfile } = useAcademyProfiles(currentUser?.academy_id)

  const [tab,           setTab]           = useState('overview')
  const [alumnoDetalle, setAlumnoDetalle] = useState<AlumnoEnriquecido | null>(null)
  const [profDetalle,   setProfDetalle]   = useState<StudentProfile | null>(null)

  const bentoRef   = useRef<HTMLDivElement>(null)
  const contentRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!tab || !contentRef.current) return
    setTimeout(() => contentRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80)
  }, [tab])

  const handleSaveAlumno = useCallback(async (userId: string, fields: AlumnoDetalleForm) => {
    const spFields = {
      full_name:     fields.full_name     || null,
      phone:         fields.phone         || null,
      email_contact: fields.email_contact || null,
      city:          fields.city          || null,
      exam_date:     fields.exam_date     || null,
      monthly_price: fields.monthly_price ? parseFloat(fields.monthly_price) : null,
    }
    await updateStudentProfile(userId, spFields)
    if (fields.access_until) {
      await supabase.from('profiles').update({ access_until: new Date(fields.access_until + 'T23:59:59').toISOString() }).eq('id', userId)
    }
  }, [updateStudentProfile])

  if (loading || loadingProfiles) return <div className={styles.state}><RefreshCw size={22} className={styles.spinner} /><p>Cargando datos…</p></div>
  if (error)  return <ErrorState message={error ?? 'Error cargando los datos del panel.'} onRetry={() => window.location.reload()} />
  if (!stats) return null

  const typedStats = stats as unknown as Stats

  const spMap: Record<string, StudentProfile> = {}
  for (const sp of studentProfiles as StudentProfile[]) spMap[sp.id] = sp

  const enrichAlumno = (a: any): AlumnoEnriquecido => {
    const sp = spMap[a.id]
    return {
      ...a,
      extended:      sp?.extended      ?? null,
      access_until:  sp?.access_until  ?? null,
      created_at:    sp?.created_at    ?? null,
      subjectName:   a.subjectName     ?? '',
      subjectColor:  a.subjectColor    ?? '#6B7280',
      enRiesgo:      a.enRiesgo        ?? false,
      diasInactivo:  a.diasInactivo    ?? null,
      diasRestantes: a.diasRestantes   ?? null,
    }
  }

  if (alumnoDetalle) {
    const statsAlumno = typedStats.bySubject.flatMap(sub => sub.alumnosConNota.map(a => ({
      ...a,
      enRiesgo:    sub.alumnosEnRiesgo.some(r => r.id === a.id),
      diasInactivo: sub.alumnosEnRiesgo.find(r => r.id === a.id)?.diasInactivo ?? null,
      fallos:      0,
    }))).find(a => a.id === alumnoDetalle.id)
    return <AlumnoDetallePanel alumno={alumnoDetalle} statsAlumno={statsAlumno} onBack={() => setAlumnoDetalle(null)} onSave={handleSaveAlumno} />
  }

  if (profDetalle) return <ProfesorDetallePanel profesor={profDetalle} onBack={() => setProfDetalle(null)} />

  const nAlertas              = typedStats.totalEnRiesgo + typedStats.totalPorExpirar
  const academyProfilesForTable = { studentProfiles: studentProfiles as StudentProfile[], staffProfiles: staffProfiles as StudentProfile[] }

  return (
    <div className={styles.page}>
      <OnboardingChecklist currentUser={currentUser} stats={typedStats} />

      <div className={styles.pageHeader}>
        <div><h1 className={styles.pageTitle}>Panel de Dirección</h1><p className={styles.pageSubtitle}>{currentUser?.academyName ?? 'Tu academia'}</p></div>
        <button className={styles.btnExport} onClick={() => exportarInforme(typedStats, currentUser?.academyName, studentProfiles as StudentProfile[])}>
          <FileText size={14} /> Exportar PDF
        </button>
      </div>

      <NarrativaCard stats={typedStats} />

      <div className={styles.kpisRow}>
        <KpiCard icon={Users}         label="Alumnos"        value={typedStats.totalAlumnos}    color="#0891B2" />
        <KpiCard icon={GraduationCap} label="Profesores"     value={typedStats.totalProfesores} color="#7C3AED" />
        <KpiCard icon={Zap}           label="Activos 7d"     value={typedStats.totalActivos}    color="#059669" sub={`${typedStats.totalAlumnos>0?Math.round(typedStats.totalActivos/typedStats.totalAlumnos*100):0}% del total`} />
        <KpiCard icon={BarChart2}     label="Nota media 30d" value={typedStats.notaGlobal!==null?`${typedStats.notaGlobal}%`:'—'} color={scoreColor(typedStats.notaGlobal)} />
        <KpiCard icon={AlertTriangle} label="En riesgo"      value={typedStats.totalEnRiesgo}   color="#DC2626" alert={typedStats.totalEnRiesgo>0} />
        <KpiCard icon={Shield}        label="Expiran pronto" value={typedStats.totalPorExpirar} color="#B45309" alert={typedStats.totalPorExpirar>0} />
      </div>

      <div ref={bentoRef}>
        <DirectorBentoNav tab={tab} setTab={setTab} stats={typedStats} nAlertas={nAlertas} studentProfiles={studentProfiles as StudentProfile[]} nMensajes={dmSent.length} nRespuestas={dmSent.filter((m: {reply_body:string|null}) => m.reply_body).length} />
      </div>

export { AlumnoDetallePanel }
