import { useState, useMemo } from 'react'
import { ArrowUpDown, ArrowRight } from 'lucide-react'
import type { StudentProfile, AlumnoEnriquecido } from '../DirectorTypes'
import { scoreColor, MASCOTAS } from '../DirectorTypes'
import styles from './AlumnosTable.module.css'


      <div ref={contentRef} className={styles.contentArea}>
        {tab==='asignaturas' && <AsignaturasDetalle stats={typedStats} studentProfiles={studentProfiles as StudentProfile[]} onAlumnoClick={a => setAlumnoDetalle(enrichAlumno(a))} />}
        {tab==='overview' && (
          <div className={styles.section}>
            <div className={styles.chartCard}>
              <div className={styles.chartCardHead}><h3 className={styles.chartCardTitle}>Sesiones por semana</h3><span className={styles.chartCardSub}>Últimas 8 semanas</span></div>
              <ActivityChart semanas={typedStats.semanas} />
              {typedStats.sesiones30d===0 && <p className={styles.empty}>Sin sesiones todavía</p>}
            </div>
            <div className={styles.subList}>
              {typedStats.bySubject.map(sub => (
                <div key={sub.id} className={styles.subCard} style={{ ['--sc' as string]: sub.color }}>
                  <div className={styles.subCardBar} />
                  <div className={styles.subCardInfo}>
                    <span className={styles.subCardName}>{sub.name}</span>
                    <div className={styles.subCardMeta}>
                      <span><Users size={11} /> {sub.totalAlumnos} alumnos</span>
                      <span><Zap size={11} /> {sub.alumnosActivos} activos</span>
                      <span><BarChart2 size={11} /> {sub.sesiones30d} sesiones 30d</span>
                    </div>
                  </div>
                  {sub.notaMedia!==null && <span className={styles.subCardNota} style={{ color: scoreColor(sub.notaMedia) }}>{sub.notaMedia}%</span>}
                </div>
              ))}
            </div>
          </div>
        )}
        {tab==='alumnos'     && <AlumnosTable stats={typedStats} academyProfiles={academyProfilesForTable} onAlumnoClick={a => setAlumnoDetalle(enrichAlumno(a))} />}
        {tab==='profesores'  && <ProfesoresTable staffProfiles={staffProfiles as StudentProfile[]} stats={typedStats} onProfesorClick={setProfDetalle} />}
        {tab==='alertas'     && <AlertasPanel stats={typedStats} onAlumnoClick={a => setAlumnoDetalle(enrichAlumno(a))} />}
        {tab==='retencion'   && <RetencionPanel profiles={(allProfiles ?? []) as ProfileSimple[]} />}
        {tab==='vencimientos' && <VencimientosPanel
          profiles={(allProfiles ?? []) as ProfileSimple[]}
          onRenovar={(id, username) => {
            const sp = studentProfiles.find((p: any) => p.id === id)
            if (sp) setAlumnoDetalle(enrichAlumno(sp as any))
          }}
        />}
        {tab==='comunicacion' && <ComunicacionPanel currentUser={currentUser} profiles={(allProfiles ?? []) as ProfileSimple[]} mensajes={dmSent} onDelete={dmDelete} />}
        {tab==='finanzas'    && <FinanzasPanel stats={typedStats} profiles={(allProfiles ?? []) as ProfileSimple[]} />}
        {tab && <button className={styles.scrollBackBtn} onClick={() => bentoRef.current?.scrollIntoView({ behavior:'smooth', block:'start' })} aria-label="Volver arriba"><ChevronUp size={18} strokeWidth={2.5} /></button>}
      </div>
    </div>
  )
}



export { AlumnosTable }
