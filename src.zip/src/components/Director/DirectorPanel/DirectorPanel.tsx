import { useState, useMemo, useCallback, useRef, useEffect } from 'react'
import { createPortal } from 'react-dom'
import {
  Users, TrendingUp, AlertTriangle, BookOpen, Copy, Check, FileText,
  Plus, RefreshCw, ChevronDown, ChevronUp, Zap, Clock, UserX, BarChart2,
  Key, Calendar, Shield, ShieldOff, RotateCcw, XCircle, TrendingDown,
  CalendarDays, ExternalLink, Bell, CheckCircle2, ArrowRight, Megaphone,
  Trash2, BookOpen as BookIcon, MessageSquare, Send, X, CornerDownLeft,
  GraduationCap, Euro, Star, UserPlus, BookMarked, Rocket, ArrowUpDown,
  Phone, MapPin, Mail, Target, Edit3, CheckCircle, Download, AlertCircle,
  BarChart2 as BarChart2Icon
} from 'lucide-react'
import { useDirector }          from '../../../hooks/useDirector'
import { useAcademyProfiles }   from '../../../hooks/useStudentProfile'
import { useProfesorMessages }  from '../../../hooks/useDirectMessages'
import type { DirectMessage }   from '../../../hooks/useDirectMessages'
import { supabase }             from '../../../lib/supabase'
import { Ripple }               from '../../magicui/Ripple'
import { AnimatedGridPattern }  from '../../magicui/AnimatedGridPattern'
import type { CurrentUser }     from '../../../types'
import ErrorState                 from '../../ui/ErrorState'

// ── Panels ────────────────────────────────────────────────────────────────
import { FinanzasPanel }     from './panels/FinanzasPanel'
import { RetencionPanel }    from './panels/RetencionPanel'
import { ComunicacionPanel } from './panels/ComunicacionPanel'
import { AlertasPanel, OnboardingChecklist, exportarInforme } from './panels/AlertasPanel'
import { VencimientosPanel } from './panels/VencimientosPanel'
import { AsignaturasDetalle, AsignaturasCard } from './panels/AsignaturasDetalle'

// ── Components ────────────────────────────────────────────────────────────
import { AlumnoDetallePanel } from './components/AlumnoDetallePanel'
import { AlumnosTable }       from './components/AlumnosTable'
import { ProfesoresTable }    from './components/ProfesoresTable'

import styles from './DirectorPanel.module.css'

  alumnosActivos:   number
  notaMedia:        number | null
  sesiones30d:      number
  enRiesgo:         number
  porExpirar:       number
  alumnosConNota:   { id: string; username: string; nota: number | null; sesiones: number }[]
  alumnosEnRiesgo:  { id: string; username: string; diasInactivo: number | null }[]
  alumnosPorExpirar:{ id: string; username: string; diasRestantes: number }[]
  profesores:       { id: string; username: string; alumnos: number; notaMedia: number | null; sesionesThisWeek: number }[]
}

interface Stats {
  totalAlumnos:    number
  totalActivos:    number
  totalProfesores: number
  totalEnRiesgo:   number
  totalPorExpirar: number
  notaGlobal:      number | null
  sesiones30d:     number
  bySubject:       SubjectStats[]
  semanas:         { label: string; sesiones: number; alumnosActivos: number; notaMedia: number | null }[]
  profesorActivity?: {
    lastAvisoByProfesor:  Record<string, { created_at: string; title: string }>
    totalAvisosByProfesor:Record<string, number>
  }
  finanzas?: {
    mrrAcademia:           number
    mrrActivos:            number
    alumnosSinPrecio:      number
    totalAlumnosConPrecio: number
    spMap:                 Record<string, { monthly_price: number | null; exam_date: string | null; full_name: string | null; city: string | null; payment_status: string }>
    pagos: {
      pagados:     number
      pendientes:  number
      vencidos:    number
      mrrCobrado:  number
      mrrPendiente:number
      mrrVencido:  number
    }
  }
}

interface ProfileSimple {
  id:           string
  username:     string
  role:         string
  access_until: string | null
  created_at:   string
}

interface StudentProfile {
  id:            string
  username:      string
  role:          string
  access_until:  string | null
  created_at:    string | null
  subject_name?: string | null
  extended:      Record<string, any> | null
}

interface AlumnoEnriquecido {
  id:            string
  username:      string
  nota:          number | null
  sesiones:      number
  subjectName:   string
  subjectColor:  string
  enRiesgo:      boolean
  diasInactivo:  number | null
  diasRestantes: number | null
  extended:      Record<string, any> | null
  access_until:  string | null
  created_at:    string | null
}

interface AlumnoDetalleForm {
  full_name:     string
  phone:         string
  email_contact: string
  city:          string
  exam_date:     string
  monthly_price: string
  access_until:  string
}

// ── Narrativa ──────────────────────────────────────────────────────────────

function NarrativaCard({ stats }: { stats: Stats }) {
  const semanas        = stats.semanas ?? []
  const semanasActivas = semanas.filter(s => s.sesiones > 0).length
  const notas          = semanas.filter(s => s.notaMedia !== null)
  const tendencia      = notas.length >= 2 ? (notas[notas.length-1]!.notaMedia! - notas[0]!.notaMedia!) : null


  let msg: string, color: string, Icon: React.ElementType
  if (stats.totalAlumnos === 0)                  { msg = 'Aún no hay alumnos. Comparte el código de invitación con tu primera clase.'; color = '#0891B2'; Icon = Rocket }
  else if (stats.totalActivos === 0)             { msg = 'Ningún alumno ha estudiado esta semana. Habla con tu profesor.';             color = '#DC2626'; Icon = AlertTriangle }
  else if (tendencia !== null && tendencia > 5)  { msg = `La nota media subió ${tendencia} puntos. ¡La clase va en la buena dirección!`; color = '#059669'; Icon = TrendingUp }
  else if (tendencia !== null && tendencia < -5) { msg = `La nota media bajó ${Math.abs(tendencia)} puntos. Revisa el plan de estudio.`; color = '#DC2626'; Icon = TrendingDown }
  else if (semanasActivas >= 6)                  { msg = `Tu academia lleva ${semanasActivas} semanas con actividad constante. ¡Buen ritmo!`; color = '#059669'; Icon = TrendingUp }
  else                                           { msg = `${stats.totalActivos} de ${stats.totalAlumnos} alumnos activos esta semana. Nota media: ${stats.notaGlobal ?? '—'}%.`; color = '#0891B2'; Icon = BarChart2 }

  return (
    <div className={styles.narrativa} style={{ ['--nc' as string]: color }}>
      <div className={styles.narrativaIcon}><Icon size={17} strokeWidth={1.8} /></div>
      <p className={styles.narrativaTexto}>{msg}</p>
    </div>
  )
}

// ── KPI Card ───────────────────────────────────────────────────────────────
function KpiCard({ icon: Icon, label, value, color, alert, sub }: {
  icon: React.ElementType; label: string; value: string | number | null | undefined; color: string; alert?: boolean; sub?: string
}) {
  return (
    <div className={styles.kpi} style={{ ['--c' as string]: color }}>
      {alert && <div className={styles.kpiAlert} />}
      <div className={styles.kpiGlow} />
      <Icon size={17} strokeWidth={1.8} className={styles.kpiIcon} />
      <div className={styles.kpiVal}>{value ?? '—'}</div>
      <div className={styles.kpiLabel}>{label}</div>
      {sub && <div className={styles.kpiSub}>{sub}</div>}
    </div>
  )
}

// ── Activity Chart ─────────────────────────────────────────────────────────
function ActivityChart({ semanas }: { semanas: Stats['semanas'] }) {
  const [hover, setHover] = useState<number | null>(null)
  if (!semanas?.length) return null
  const maxSes = Math.max(...semanas.map(s => s.sesiones), 1)
  const W = 560, H = 110, BAR_W = 38, GAP = 28
  const offsetX = (W - semanas.length * (BAR_W + GAP)) / 2
  return (
    <div className={styles.chartWrap}>
      <svg viewBox={`0 0 ${W} ${H + 36}`} className={styles.chartSvg}>
        {semanas.map((s, i) => {
          const x    = offsetX + i * (BAR_W + GAP)
          const barH = Math.max((s.sesiones / maxSes) * H, s.sesiones > 0 ? 4 : 0)
          const y    = H - barH
          const isH  = hover === i
          return (
            <g key={i} style={{ cursor: 'pointer' }} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
              <rect x={x} y={0} width={BAR_W} height={H} rx={6} fill="var(--surface-dim)" opacity={0.6} />
              <rect x={x} y={y} width={BAR_W} height={barH} rx={6} fill={isH ? 'var(--primary)' : '#0891B2'} opacity={isH ? 1 : 0.72} style={{ transition: 'all 0.18s' }} />
              {barH > 8 && <rect x={x+4} y={y+3} width={7} height={3} rx={2} fill="white" opacity={0.3} />}
              {s.sesiones > 0 && <text x={x+BAR_W/2} y={y-5} textAnchor="middle" fontSize="10" fill="var(--ink-muted)" fontWeight="600">{s.sesiones}</text>}
              <text x={x+BAR_W/2} y={H+16} textAnchor="middle" fontSize="9" fill="var(--ink-muted)">{s.label}</text>
              {isH && (
                <g>
                  <rect x={x+BAR_W/2-28} y={y-44} width={56} height={34} rx={6} fill="var(--ink)" opacity={0.92} />
                  <text x={x+BAR_W/2} y={y-28} textAnchor="middle" fontSize="10" fill="white" fontWeight="700">{s.sesiones} ses.</text>
                  <text x={x+BAR_W/2} y={y-14} textAnchor="middle" fontSize="9" fill="#9CA3AF">{s.alumnosActivos} activos</text>
                </g>
              )}
            </g>
          )
        })}
      </svg>
    </div>
  )
}

// ── InfoRow ────────────────────────────────────────────────────────────────
function InfoRow({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: string | null | undefined }) {
  if (!value) return null
  return (
    <div className={styles.infoRow}>
      <Icon size={13} className={styles.infoIcon} />
      <span className={styles.infoLabel}>{label}</span>
      <span className={styles.infoValue}>{value}</span>
    </div>
  )
}

// ── AlumnoDetallePanel ─────────────────────────────────────────────────────

function DirectorBentoNav({ tab, setTab, stats, nAlertas, studentProfiles, nMensajes, nRespuestas }: {
  tab: string; setTab: (t: string) => void; stats: Stats; nAlertas: number; studentProfiles: StudentProfile[]
  nMensajes: number; nRespuestas: number
}) {




