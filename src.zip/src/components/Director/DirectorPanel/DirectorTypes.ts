// Local types for Director panel
// Global types re-exported for convenience
export type { DirectorStats } from '../../../types'
export type { CurrentUser } from '../../../types'

export interface StudentProfile {
  id:            string
  username:      string
  role:          string
  access_until:  string | null
  created_at:    string | null
  subject_name?: string | null
  extended:      Record<string, unknown> | null
}

export interface ProfileSimple {
  id:           string
  username:     string
  role:         string
  access_until: string | null
  created_at:   string
}

export interface AlumnoEnriquecido {
  id:            string
  username:      string
  nota:          number | null
  sesiones:      number
  subjectName:   string
  subjectColor:  string
  enRiesgo:      boolean
  diasInactivo:  number | null
  diasRestantes: number | null
  extended:      Record<string, unknown> | null
  access_until:  string | null
  created_at:    string | null
}

export interface AlumnoDetalleForm {
  full_name:     string
  phone:         string
  email_contact: string
  city:          string
  exam_date:     string
  monthly_price: string
  access_until:  string
}

export function scoreColor(s: number | null | undefined): string {
  if (s == null) return '#6B7280'
  if (s >= 80) return '#059669'
  if (s >= 60) return '#0891B2'
  if (s >= 40) return '#B45309'
  return '#DC2626'
}

export function fmt(iso: string | null | undefined): string {
  if (!iso) return '—'
  return new Date(iso).toLocaleDateString('es-ES', { day:'2-digit', month:'short', year:'numeric' })
}

export const MASCOTAS: Record<string, {emoji:string}> = {
  zorro: {emoji:'🦊'}, gato: {emoji:'🐱'}, perro: {emoji:'🐶'},
  conejo: {emoji:'🐰'}, oso: {emoji:'🐻'}, panda: {emoji:'🐼'},
}