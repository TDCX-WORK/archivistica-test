import { useState, useMemo } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Users, Zap, AlertTriangle, Shield, BarChart2, BookOpen,
  RefreshCw, TrendingUp, TrendingDown, GraduationCap,
  Clock, FileText, CheckCircle, X, Check, Key, Euro,
  UserPlus, Star, BookMarked, Rocket, ArrowUpDown, ArrowRight,
  MessageSquare, Send, Trash2, CornerDownLeft, Megaphone, RotateCcw,
  Phone, MapPin, Mail, Target, Calendar, Edit3,
  Save, ChevronLeft, ChevronUp, ChevronDown
} from 'lucide-react'
import { scoreColor, MASCOTAS } from '../DirectorTypes'
import styles from './AsignaturasDetalle.module.css'

import type { SubjectStats, Stats, ProfileSimple, StudentProfile, AlumnoEnriquecido, AlumnoDetalleForm } from '../DirectorTypes'

// ── AsignaturasDetalle ─────────────────────────────────────────────────────
function AsignaturasDetalle({ stats, studentProfiles, onAlumnoClick }: {
  stats:           Stats
  studentProfiles: StudentProfile[]
  onAlumnoClick:   (a: AlumnoEnriquecido) => void
}) {
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [sortBy,     setSortBy]     = useState<'nota' | 'sesiones'>('nota')
  const [sortDir,    setSortDir]    = useState<'asc' | 'desc'>('desc')

  const spMap: Record<string, StudentProfile> = {}
  for (const sp of studentProfiles) spMap[sp.id] = sp

  const sub     = stats.bySubject?.find(s => s.id === expandedId)
  const alumnos = useMemo<AlumnoEnriquecido[]>(() => {
    if (!sub) return []
    return [...sub.alumnosConNota].map(a => ({
      ...a,
      subjectName:   sub.name,
      subjectColor:  sub.color ?? '#6B7280',
      enRiesgo:      sub.alumnosEnRiesgo.some(r => r.id === a.id),
      diasInactivo:  sub.alumnosEnRiesgo.find(r => r.id === a.id)?.diasInactivo ?? null,
      diasRestantes: sub.alumnosPorExpirar.find(r => r.id === a.id)?.diasRestantes ?? null,
      extended:      spMap[a.id]?.extended ?? null,
      access_until:  spMap[a.id]?.access_until ?? null,
      created_at:    spMap[a.id]?.created_at ?? null,
    })).sort((a, b) => {
      const va = (a as any)[sortBy] ?? -1, vb = (b as any)[sortBy] ?? -1
      return sortDir === 'desc' ? vb - va : va - vb
    })
  }, [sub, sortBy, sortDir, studentProfiles])

  const handleSort = (col: 'nota' | 'sesiones') => {
    if (sortBy === col) setSortDir(d => d === 'desc' ? 'asc' : 'desc')
    else { setSortBy(col); setSortDir('desc') }
  }

  const handleToggle = (id: string) => {
    setExpandedId(prev => prev === id ? null : id)
  }

  if (!stats.bySubject?.length) return null

  // Ranking comparativo
  const sorted       = [...stats.bySubject].sort((a,b) => (b.notaMedia??-1) - (a.notaMedia??-1))
  const maxNota      = Math.max(...stats.bySubject.map(s => s.notaMedia ?? 0), 1)
  const maxSesiones  = Math.max(...stats.bySubject.map(s => s.sesiones30d), 1)

  return (
    <div className={styles.asigDetalle}>

      {/* Comparativa ranking — solo si hay más de 1 asignatura */}
      {stats.bySubject.length > 1 && (
        <div className={styles.asigComparativa}>
          <div className={styles.asigComparativaTitulo}>
            <BarChart2 size={14}/> Comparativa entre asignaturas
          </div>
          <div className={styles.asigComparativaGrid}>
            {sorted.map((s, i) => (
              <div key={s.id} className={styles.asigComparativaRow}
                onClick={() => setExpandedId(s.id)}
                style={{cursor:'pointer'}}>
                <div className={styles.asigComparativaRank}
                  style={{color: i===0?'#D97706':i===1?'#94A3B8':'#CD7C54'}}>
                  #{i+1}
                </div>
                <div className={styles.asigComparativaNombre}>
                  <div className={styles.alumnoDot} style={{background:s.color??'#6B7280'}}/>
                  <span>{s.name}</span>
                </div>
                <div className={styles.asigComparativaBarWrap}>
                  <div className={styles.asigComparativaBarLabel}>
                    <span style={{color: scoreColor(s.notaMedia), fontWeight:800}}>
                      {s.notaMedia!==null?`${s.notaMedia}%`:'—'}
                    </span>
                  </div>
                  <div className={styles.asigComparativaBar}>
                    <div className={styles.asigComparativaBarFill} style={{
                      width: `${s.notaMedia!==null ? (s.notaMedia/maxNota)*100 : 0}%`,
                      background: `linear-gradient(90deg, ${s.color??'#6B7280'}, ${s.color??'#6B7280'}88)`,
                      boxShadow: `0 0 8px ${s.color??'#6B7280'}44`,
                    }}/>
                  </div>
                </div>
                <div className={styles.asigComparativaMeta}>
                  <span>{s.totalAlumnos} alumnos</span>
                  <span>{s.sesiones30d} sesiones</span>
                  {s.enRiesgo > 0 && <span style={{color:'#DC2626'}}>⚠ {s.enRiesgo}</span>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className={styles.asigCards}>
        {stats.bySubject.map((s, i) => {
          const isOpen  = expandedId === s.id
          const notaCol = scoreColor(s.notaMedia)
          const pctAct  = s.totalAlumnos > 0 ? Math.round((s.alumnosActivos / s.totalAlumnos) * 100) : 0
          // Shape alterna entre dos variantes para dar sensación de "encajan"
          const shape   = i % 2 === 0 ? styles.shapeA : styles.shapeB
          const alertTotal = s.enRiesgo + s.porExpirar
          const alertTone  = s.enRiesgo > 0 ? 'danger' : s.porExpirar > 0 ? 'amber' : 'muted'
          const alertLabel = s.enRiesgo > 0
            ? `${s.enRiesgo} en riesgo`
            : s.porExpirar > 0 ? `${s.porExpirar} expiran` : 'Sin alertas'

          return (
            <div
              key={s.id}
              className={[styles.asigDetailCard, shape, isOpen ? styles.asigDetailCardOpen : ''].join(' ')}
              style={{ ['--sc' as string]: s.color }}
            >
              <span className={styles.asigDetailGlow} aria-hidden="true" />

              <header className={styles.asigDetailHead}>
                <div className={styles.asigDetailHeadLeft}>
                  <span className={styles.asigDetailDot} />
                  <h3 className={styles.asigDetailName}>{s.name}</h3>
                </div>
                <span className={styles.asigDetailSess}>
                  <strong>{s.sesiones30d}</strong> sesiones / 30d
                </span>
              </header>

              {/* KPIs en mini-cards */}
              <div className={styles.kpiGrid}>
                <div className={styles.kpiTile}>
                  <div className={styles.kpiTileIcon}><Users size={11} strokeWidth={2.4} /></div>
                  <div className={styles.kpiTileBody}>
                    <span className={styles.kpiTileVal}>{s.totalAlumnos}</span>
                    <span className={styles.kpiTileLabel}>Alumnos</span>
                  </div>
                </div>

                <div className={styles.kpiTile}>
                  <div className={styles.kpiTileIcon} data-tone="accent"><Zap size={11} strokeWidth={2.4} /></div>
                  <div className={styles.kpiTileBody}>
                    <span className={[styles.kpiTileVal, styles.kpiTileValAccent].join(' ')}>{s.alumnosActivos}</span>
                    <span className={styles.kpiTileLabel}>Activos · {pctAct}%</span>
                  </div>
                </div>

                <div className={styles.kpiTile}>
                  <div className={styles.kpiTileIcon} data-tone="ink"><Target size={11} strokeWidth={2.4} /></div>
                  <div className={styles.kpiTileBody}>
                    <span className={styles.kpiTileVal} style={{ color: notaCol }}>
                      {s.notaMedia !== null ? `${s.notaMedia}%` : '—'}
                    </span>
                    <span className={styles.kpiTileLabel}>Nota media</span>
                  </div>
                </div>

                <div className={styles.kpiTile}>
                  <div className={styles.kpiTileIcon} data-tone={alertTone}>
                    <AlertTriangle size={11} strokeWidth={2.4} />
                  </div>
                  <div className={styles.kpiTileBody}>
                    <span
                      className={styles.kpiTileVal}
                      style={{
                        color: s.enRiesgo > 0 ? 'var(--danger)'
                             : s.porExpirar > 0 ? 'var(--amber)' : 'var(--ink)',
                      }}
                    >
                      {alertTotal}
                    </span>
                    <span className={styles.kpiTileLabel}>{alertLabel}</span>
                  </div>
                </div>
              </div>

              <footer className={styles.asigDetailFoot}>
                <button
                  type="button"
                  className={styles.verAlumnosBtn}
                  onClick={() => handleToggle(s.id)}
                  aria-expanded={isOpen}
                  aria-controls={`asig-alumnos-${s.id}`}
                >
                  <span>{isOpen ? 'Ocultar alumnos' : 'Ver alumnos'}</span>
                  <motion.span
                    className={styles.verAlumnosChev}
                    animate={{ rotate: isOpen ? 180 : 0 }}
                    transition={{ duration: 0.2, ease: [0.4, 0, 0.2, 1] }}
                  >
                    <ChevronDown size={14} strokeWidth={2.5} />
                  </motion.span>
                </button>
              </footer>

              <AnimatePresence initial={false}>
                {isOpen && sub && sub.id === s.id && (
                  <motion.div
                    key="panel"
                    id={`asig-alumnos-${s.id}`}
                    className={styles.asigAlumnosWrap}
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.28, ease: [0.4, 0, 0.2, 1] }}
                  >
                    <div className={styles.asigAlumnos}>
                      <div className={styles.asigAlumnosHead}>
                        <div className={styles.asigAlumnosTitleWrap}>
                          <span className={styles.asigAlumnosCount}>{alumnos.length}</span>
                          <span className={styles.asigAlumnosLabel}>
                            {alumnos.length === 1 ? 'alumno' : 'alumnos'} en {sub.name}
                          </span>
                        </div>
                      </div>

                      {alumnos.length === 0 ? (
                        <p className={styles.empty}>Sin alumnos en esta asignatura</p>
                      ) : (
                        <div className={styles.alumnosTable}>
                          <div className={styles.alumnosTableHead}>
                            <span>Alumno</span>
                            <button className={styles.sortBtn} onClick={() => handleSort('nota')}>
                              Nota <ArrowUpDown size={10} style={{ opacity: sortBy === 'nota' ? 1 : 0.4 }} />
                            </button>
                            <button className={styles.sortBtn} onClick={() => handleSort('sesiones')}>
                              Sesiones <ArrowUpDown size={10} style={{ opacity: sortBy === 'sesiones' ? 1 : 0.4 }} />
                            </button>
                            <span>Estado</span>
                            <span />
                          </div>
                          {alumnos.map(a => {
                            const mascota = MASCOTAS[String(a.extended?.mascota ?? '')]
                            const nombre  = String(a.extended?.full_name ?? '') || a.username
                            const color   = scoreColor(a.nota)
                            return (
                              <div
                                key={a.id}
                                className={styles.alumnoRow}
                                onClick={() => onAlumnoClick(a)}
                              >
                                <div className={styles.alumnoNameCell}>
                                  <div className={styles.alumnoAvatarSm}>
                                    {mascota
                                      ? <img src={mascota.img} alt={mascota.nombre} className={styles.avatarImg} />
                                      : nombre[0]!.toUpperCase()
                                    }
                                  </div>
                                  <div className={styles.alumnoNameBlock}>
                                    <div className={styles.alumnoNameMain}>{nombre}</div>
                                    {a.extended?.full_name && (
                                      <div className={styles.alumnoNameUser}>@{a.username}</div>
                                    )}
                                  </div>
                                </div>
                                <span className={styles.alumnoNota} style={{ color }}>
                                  {a.nota !== null ? `${a.nota}%` : '—'}
                                </span>
                                <span className={styles.alumnoSesiones}>{a.sesiones}</span>
                                <span className={a.enRiesgo ? styles.estadoRiesgo : styles.estadoOk}>
                                  {a.enRiesgo ? `${a.diasInactivo ?? '?'}d inactivo` : 'Activo'}
                                </span>
                                <ArrowRight size={13} className={styles.alumnoArrow} />
                              </div>
                            )
                          })}
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ── AsignaturasCard ────────────────────────────────────────────────────────
function AsignaturasCard({ stats }: { stats: Stats }) {
  const subs = stats.bySubject ?? []
  if (subs.length === 0) return <div className={styles.examEmpty}><BookOpen size={22} strokeWidth={1.4} /><p>Sin asignaturas configuradas</p></div>
  return (
    <div className={styles.asigList}>
      {subs.map(sub => (
        <div key={sub.id} className={styles.asigRow}>
          <div className={styles.asigDot} style={{ background: sub.color }} />
          <div className={styles.asigInfo}>
            <span className={styles.asigNombre}>{sub.name}</span>
            <span className={styles.asigMeta}>{sub.totalAlumnos} alumnos · {sub.alumnosActivos} activos</span>
          </div>
          {sub.notaMedia !== null && <span className={styles.asigNota} style={{ color: scoreColor(sub.notaMedia) }}>{sub.notaMedia}%</span>}
        </div>
      ))}
    </div>
  )
}


export { AsignaturasDetalle, AsignaturasCard }
