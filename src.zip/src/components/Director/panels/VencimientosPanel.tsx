import { RotateCcw, CheckCircle } from 'lucide-react'
import type { ProfileSimple } from '../DirectorTypes'
import styles from './VencimientosPanel.module.css'

// ── VencimientosPanel ─────────────────────────────────────────────────────
function VencimientosPanel({ profiles, onRenovar }: {
  profiles:  ProfileSimple[]
  onRenovar: (id: string, username: string) => void
}) {
  const now     = new Date()
  const alumnos = profiles.filter(p => p.role === 'alumno')

  const enriquecidos = alumnos
    .filter(a => a.access_until)
    .map(a => ({
      id:          a.id,
      username:    a.username,
      accessUntil: a.access_until!,
      dias:        Math.ceil((new Date(a.access_until!).getTime() - now.getTime()) / 86400000),
    }))
    .sort((a, b) => a.dias - b.dias)

  const expirados  = enriquecidos.filter(a => a.dias <= 0)
  const esta_semana = enriquecidos.filter(a => a.dias > 0 && a.dias <= 7)
  const este_mes   = enriquecidos.filter(a => a.dias > 7 && a.dias <= 30)
  const proximos   = enriquecidos.filter(a => a.dias > 30 && a.dias <= 90)
  const sin_acceso = alumnos.filter(a => !a.access_until)

  const fmtFecha = (iso: string) =>
    new Date(iso).toLocaleDateString('es-ES', { day:'2-digit', month:'short', year:'numeric' })

  const Grupo = ({ titulo, items, color, urgente }: {
    titulo: string; items: typeof enriquecidos; color: string; urgente?: boolean
  }) => {
    if (!items.length) return null
    return (
      <div className={styles.vencGrupo}>
        <div className={styles.vencGrupoTitulo} style={{color}}>
          <span className={styles.vencGrupoDot} style={{background:color}}/>
          {titulo}
          <span className={styles.vencGrupoCount}>{items.length}</span>
        </div>
        <div className={styles.vencCardsGrid}>
          {items.map(a => (
            <div key={a.id} className={styles.vencCard} style={{
              borderLeft: `3px solid ${color}`,
              boxShadow: urgente ? `0 4px 16px ${color}22` : undefined,
            }}>
              <div className={styles.vencCardHead}>
                <div className={styles.vencAvatar} style={{background:`${color}15`,color}}>
                  {a.username[0]!.toUpperCase()}
                </div>
                <div className={styles.vencInfo}>
                  <span className={styles.vencNombre}>{a.username}</span>
                  <span className={styles.vencFecha}>{a.dias <= 0 ? 'Expirado' : fmtFecha(a.accessUntil)}</span>
                </div>
                <div className={styles.vencDiasBadge} style={{background:`${color}15`,color}}>
                  {a.dias <= 0 ? `${Math.abs(a.dias)}d expirado` : `${a.dias}d`}
                </div>
              </div>
              <button className={styles.vencBtnRenovar} style={{'--vc':color} as React.CSSProperties}
                onClick={() => onRenovar(a.id, a.username)}>
                <RotateCcw size={11}/> Renovar acceso
              </button>
            </div>
          ))}
        </div>
      </div>
    )
  }

  const totalAlertas = expirados.length + esta_semana.length

  return (
    <div className={styles.vencWrap}>
      {/* KPIs resumen */}
      <div className={styles.vencKpis}>
        <div className={styles.vencKpi} style={{borderColor: expirados.length>0?'rgba(220,38,38,0.3)':undefined}}>
          <span className={styles.vencKpiVal} style={{color:expirados.length>0?'#DC2626':'var(--ink)'}}>{expirados.length}</span>
          <span className={styles.vencKpiLabel}>Expirados</span>
        </div>
        <div className={styles.vencKpi} style={{borderColor: esta_semana.length>0?'rgba(217,119,6,0.3)':undefined}}>
          <span className={styles.vencKpiVal} style={{color:esta_semana.length>0?'#D97706':'var(--ink)'}}>{esta_semana.length}</span>
          <span className={styles.vencKpiLabel}>Esta semana</span>
        </div>
        <div className={styles.vencKpi}>
          <span className={styles.vencKpiVal} style={{color:este_mes.length>0?'#D97706':'var(--ink)'}}>{este_mes.length}</span>
          <span className={styles.vencKpiLabel}>Este mes</span>
        </div>
        <div className={styles.vencKpi}>
          <span className={styles.vencKpiVal}>{proximos.length}</span>
          <span className={styles.vencKpiLabel}>En 30–90 días</span>
        </div>
      </div>

      {totalAlertas === 0 && expirados.length === 0 && (
        <div className={styles.vencOk}>
          <CheckCircle size={32} strokeWidth={1.4} style={{color:'#059669'}}/>
          <p>No hay accesos urgentes esta semana</p>
        </div>
      )}

      <Grupo titulo="Expirados — acción inmediata" items={expirados} color="#DC2626" urgente />
      <Grupo titulo="Expiran esta semana" items={esta_semana} color="#D97706" urgente />
      <Grupo titulo="Expiran este mes" items={este_mes} color="#F59E0B" />
      <Grupo titulo="Expiran en 30–90 días" items={proximos} color="#0891B2" />

      {sin_acceso.length > 0 && (
        <div className={styles.vencGrupo}>
          <div className={styles.vencGrupoTitulo} style={{color:'var(--ink-subtle)'}}>
            <span className={styles.vencGrupoDot} style={{background:'var(--ink-subtle)'}}/>
            Sin fecha de acceso asignada
            <span className={styles.vencGrupoCount}>{sin_acceso.length}</span>
          </div>
          <div className={styles.vencCardsGrid}>
            {sin_acceso.map(a => (
              <div key={a.id} className={styles.vencCard} style={{borderLeft:'3px solid var(--line)'}}>
                <div className={styles.vencCardHead}>
                  <div className={styles.vencAvatar} style={{background:'var(--surface-off)',color:'var(--ink-muted)'}}>
                    {a.username[0]!.toUpperCase()}
                  </div>
                  <div className={styles.vencInfo}>
                    <span className={styles.vencNombre}>{a.username}</span>
                    <span className={styles.vencFecha}>Acceso indefinido</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ── AsignaturasDetalle ─────────────────────────────────────────────────────

export { VencimientosPanel }
