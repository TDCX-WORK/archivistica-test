import { useState, useMemo, useCallback, useRef, useEffect } from 'react'
import { useDirector }        from '../../../hooks/useDirector'
import { useProfesorMessages } from '../../../hooks/useDirectMessages'
import type { DirectMessage }  from '../../../hooks/useDirectMessages'
import { useAcademyProfiles } from '../../../hooks/useStudentProfile'
import { supabase }           from '../../../lib/supabase'
import {
  Users, Zap, AlertTriangle, Shield, BarChart2, BookOpen,
  RefreshCw, TrendingUp, TrendingDown, GraduationCap,
  Clock, FileText, CheckCircle, X, Check, Key, Euro,
  UserPlus, Star, BookMarked, Rocket, ArrowUpDown, ArrowRight, MessageSquare, Send, Trash2, CornerDownLeft, Megaphone, RotateCcw,
  Phone, MapPin, Mail, Target, Calendar, Edit3,
  Save, ChevronLeft, ChevronUp
} from 'lucide-react'
import { Ripple }              from '../../magicui/Ripple'
import { AnimatedGridPattern } from '../../magicui/AnimatedGridPattern'
import type { CurrentUser } from '../../../types'
import ErrorState      from '../../ui/ErrorState'
import styles from './DirectorPanel.module.css'

const MASCOTAS: Record<string, { emoji: string; nombre: string }> = {
  zorro:    { emoji: '🦊', nombre: 'Zorro'    },
  buho:     { emoji: '🦉', nombre: 'Búho'     },
  leon:     { emoji: '🦁', nombre: 'León'     },
  tortuga:  { emoji: '🐢', nombre: 'Tortuga'  },
  aguila:   { emoji: '🦅', nombre: 'Águila'   },
  dragon:   { emoji: '🐉', nombre: 'Dragón'   },
  lobo:     { emoji: '🐺', nombre: 'Lobo'     },
  mariposa: { emoji: '🦋', nombre: 'Mariposa' },
}

const scoreColor = (s: number | null | undefined): string => {
  if (s == null) return '#6B7280'
  if (s >= 80) return '#059669'
  if (s >= 60) return '#0891B2'
  if (s >= 40) return '#B45309'
  return '#DC2626'
}

const fmt = (iso: string | null | undefined): string =>
  iso ? new Date(iso).toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' }) : '—'

// ── Types ──────────────────────────────────────────────────────────────────
interface SubjectStats {
  id:               string
  slug:             string
  name:             string
  color:            string
  totalAlumnos:     number
  alumnosActivos:   number
  notaMedia:        number | null
  sesiones30d:      number
  enRiesgo:         number
  porExpirar:       number
  alumnosConNota:   { id: string; username: string; nota: number | null; sesiones: number }[]
  alumnosEnRiesgo:  { id: string; username: string; diasInactivo: number | null }[]
  alumnosPorExpirar:{ id: string; username: string; diasRestantes: number }[]
  profesores:       { id: string; username: string; alumnos: number; notaMedia: number | null; sesionesThisWeek: number }[]
}

interface Stats {
  totalAlumnos:    number
  totalActivos:    number
  totalProfesores: number
  totalEnRiesgo:   number
  totalPorExpirar: number
  notaGlobal:      number | null
  sesiones30d:     number
  bySubject:       SubjectStats[]
  semanas:         { label: string; sesiones: number; alumnosActivos: number; notaMedia: number | null }[]
  profesorActivity?: {
    lastAvisoByProfesor:  Record<string, { created_at: string; title: string }>
    totalAvisosByProfesor:Record<string, number>
  }
  finanzas?: {
    mrrAcademia:           number
    mrrActivos:            number
    alumnosSinPrecio:      number
    totalAlumnosConPrecio: number
    spMap:                 Record<string, { monthly_price: number | null; exam_date: string | null; full_name: string | null; city: string | null; payment_status: string }>
    pagos: {
      pagados:     number
      pendientes:  number
      vencidos:    number
      mrrCobrado:  number
      mrrPendiente:number
      mrrVencido:  number
    }
  }
}

interface ProfileSimple {
  id:           string
  username:     string
  role:         string
  access_until: string | null
  created_at:   string
}

interface StudentProfile {
  id:            string
  username:      string
  role:          string
  access_until:  string | null
  created_at:    string | null
  subject_name?: string | null
  extended:      Record<string, any> | null
}

interface AlumnoEnriquecido {
  id:            string
  username:      string
  nota:          number | null
  sesiones:      number
  subjectName:   string
  subjectColor:  string
  enRiesgo:      boolean
  diasInactivo:  number | null
  diasRestantes: number | null
  extended:      Record<string, any> | null
  access_until:  string | null
  created_at:    string | null
}

interface AlumnoDetalleForm {
  full_name:     string
  phone:         string
  email_contact: string
  city:          string
  exam_date:     string
  monthly_price: string
  access_until:  string
}

// ── Narrativa ──────────────────────────────────────────────────────────────
function NarrativaCard({ stats }: { stats: Stats }) {
  const semanas        = stats.semanas ?? []
  const semanasActivas = semanas.filter(s => s.sesiones > 0).length
  const notas          = semanas.filter(s => s.notaMedia !== null)
  const tendencia      = notas.length >= 2 ? (notas[notas.length-1]!.notaMedia! - notas[0]!.notaMedia!) : null

  let msg: string, color: string, Icon: React.ElementType
  if (stats.totalAlumnos === 0)                  { msg = 'Aún no hay alumnos. Comparte el código de invitación con tu primera clase.'; color = '#0891B2'; Icon = Rocket }
  else if (stats.totalActivos === 0)             { msg = 'Ningún alumno ha estudiado esta semana. Habla con tu profesor.';             color = '#DC2626'; Icon = AlertTriangle }
  else if (tendencia !== null && tendencia > 5)  { msg = `La nota media subió ${tendencia} puntos. ¡La clase va en la buena dirección!`; color = '#059669'; Icon = TrendingUp }
  else if (tendencia !== null && tendencia < -5) { msg = `La nota media bajó ${Math.abs(tendencia)} puntos. Revisa el plan de estudio.`; color = '#DC2626'; Icon = TrendingDown }
  else if (semanasActivas >= 6)                  { msg = `Tu academia lleva ${semanasActivas} semanas con actividad constante. ¡Buen ritmo!`; color = '#059669'; Icon = TrendingUp }
  else                                           { msg = `${stats.totalActivos} de ${stats.totalAlumnos} alumnos activos esta semana. Nota media: ${stats.notaGlobal ?? '—'}%.`; color = '#0891B2'; Icon = BarChart2 }

  return (
    <div className={styles.narrativa} style={{ ['--nc' as string]: color }}>
      <div className={styles.narrativaIcon}><Icon size={17} strokeWidth={1.8} /></div>
      <p className={styles.narrativaTexto}>{msg}</p>
    </div>
  )
}

// ── KPI Card ───────────────────────────────────────────────────────────────
function KpiCard({ icon: Icon, label, value, color, alert, sub }: {
  icon: React.ElementType; label: string; value: string | number | null | undefined; color: string; alert?: boolean; sub?: string
}) {
  return (
    <div className={styles.kpi} style={{ ['--c' as string]: color }}>
      {alert && <div className={styles.kpiAlert} />}
      <div className={styles.kpiGlow} />
      <Icon size={17} strokeWidth={1.8} className={styles.kpiIcon} />
      <div className={styles.kpiVal}>{value ?? '—'}</div>
      <div className={styles.kpiLabel}>{label}</div>
      {sub && <div className={styles.kpiSub}>{sub}</div>}
    </div>
  )
}

// ── Activity Chart ─────────────────────────────────────────────────────────
function ActivityChart({ semanas }: { semanas: Stats['semanas'] }) {
  const [hover, setHover] = useState<number | null>(null)
  if (!semanas?.length) return null
  const maxSes = Math.max(...semanas.map(s => s.sesiones), 1)
  const W = 560, H = 110, BAR_W = 38, GAP = 28
  const offsetX = (W - semanas.length * (BAR_W + GAP)) / 2
  return (
    <div className={styles.chartWrap}>
      <svg viewBox={`0 0 ${W} ${H + 36}`} className={styles.chartSvg}>
        {semanas.map((s, i) => {
          const x    = offsetX + i * (BAR_W + GAP)
          const barH = Math.max((s.sesiones / maxSes) * H, s.sesiones > 0 ? 4 : 0)
          const y    = H - barH
          const isH  = hover === i
          return (
            <g key={i} style={{ cursor: 'pointer' }} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
              <rect x={x} y={0} width={BAR_W} height={H} rx={6} fill="var(--surface-dim)" opacity={0.6} />
              <rect x={x} y={y} width={BAR_W} height={barH} rx={6} fill={isH ? 'var(--primary)' : '#0891B2'} opacity={isH ? 1 : 0.72} style={{ transition: 'all 0.18s' }} />
              {barH > 8 && <rect x={x+4} y={y+3} width={7} height={3} rx={2} fill="white" opacity={0.3} />}
              {s.sesiones > 0 && <text x={x+BAR_W/2} y={y-5} textAnchor="middle" fontSize="10" fill="var(--ink-muted)" fontWeight="600">{s.sesiones}</text>}
              <text x={x+BAR_W/2} y={H+16} textAnchor="middle" fontSize="9" fill="var(--ink-muted)">{s.label}</text>
              {isH && (
                <g>
                  <rect x={x+BAR_W/2-28} y={y-44} width={56} height={34} rx={6} fill="var(--ink)" opacity={0.92} />
                  <text x={x+BAR_W/2} y={y-28} textAnchor="middle" fontSize="10" fill="white" fontWeight="700">{s.sesiones} ses.</text>
                  <text x={x+BAR_W/2} y={y-14} textAnchor="middle" fontSize="9" fill="#9CA3AF">{s.alumnosActivos} activos</text>
                </g>
              )}
            </g>
          )
        })}
      </svg>
    </div>
  )
}

// ── InfoRow ────────────────────────────────────────────────────────────────
function InfoRow({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: string | null | undefined }) {
  if (!value) return null
  return (
    <div className={styles.infoRow}>
      <Icon size={13} className={styles.infoIcon} />
      <span className={styles.infoLabel}>{label}</span>
      <span className={styles.infoValue}>{value}</span>
    </div>
  )
}

// ── AlumnoDetallePanel ─────────────────────────────────────────────────────
function AlumnoDetallePanel({ alumno, statsAlumno, onBack, onSave }: {
  alumno:      AlumnoEnriquecido
  statsAlumno: { nota: number | null; sesiones: number; fallos: number; enRiesgo: boolean; diasInactivo: number | null } | undefined
  onBack:      () => void
  onSave:      (id: string, fields: AlumnoDetalleForm) => Promise<void>
}) {
  const ext     = alumno.extended ?? {}
  const mascota = MASCOTAS[ext.mascota as string] ?? null
  const [editando, setEditando] = useState(false)
  const [form,     setForm]     = useState<AlumnoDetalleForm>({
    full_name:     String(ext.full_name     ?? ''),
    phone:         String(ext.phone         ?? ''),
    email_contact: String(ext.email_contact ?? ''),
    city:          String(ext.city          ?? ''),
    exam_date:     String(ext.exam_date     ?? ''),
    monthly_price: String(ext.monthly_price ?? ''),
    access_until:  alumno.access_until?.slice(0, 10) ?? '',
  })
  const [saving, setSaving] = useState(false)
  const handleSave = async () => { setSaving(true); await onSave(alumno.id, form); setSaving(false); setEditando(false) }

  return (
    <div className={styles.detallePanel}>
      <div className={styles.detallePanelHead}>
        <button className={styles.btnBack} onClick={onBack}><ChevronLeft size={16} /> Volver</button>
        <div className={styles.detalleAvatar} style={{ background: scoreColor(statsAlumno?.nota) + '22', color: scoreColor(statsAlumno?.nota) }}>
          {mascota ? mascota.emoji : alumno.username[0]!.toUpperCase()}
        </div>
        <div className={styles.detalleTitleWrap}>
          <h2 className={styles.detalleTitle}>{String(ext.full_name ?? alumno.username)}</h2>
          <div className={styles.detalleMeta}>
            <span className={styles.detalleUsername}>@{alumno.username}</span>
            {mascota && <span className={styles.detalleMascota}>{mascota.emoji} {mascota.nombre}</span>}
          </div>
        </div>
        <button className={styles.btnEditarPerfil} onClick={() => setEditando(v => !v)}>
          <Edit3 size={13} /> {editando ? 'Cancelar' : 'Editar'}
        </button>
      </div>

      <div className={styles.detalleLayout}>
        <div className={styles.detalleLeft}>
          <div className={styles.detalleCard}>
            <h3 className={styles.detalleCardTitle}>Datos personales</h3>
            {editando ? (
              <div className={styles.editForm}>
                {([
                  { key: 'full_name',     label: 'Nombre completo',   type: 'text',   placeholder: 'Nombre y apellidos' },
                  { key: 'phone',         label: 'Teléfono',           type: 'tel',    placeholder: '612 345 678' },
                  { key: 'email_contact', label: 'Email',              type: 'email',  placeholder: 'email@ejemplo.com' },
                  { key: 'city',          label: 'Ciudad',             type: 'text',   placeholder: 'Madrid' },
                  { key: 'exam_date',     label: 'Fecha del examen',   type: 'date',   placeholder: '' },
                  { key: 'monthly_price', label: 'Precio mensual (€)', type: 'number', placeholder: '89' },
                  { key: 'access_until',  label: 'Acceso hasta',       type: 'date',   placeholder: '' },
                ] as { key: keyof AlumnoDetalleForm; label: string; type: string; placeholder: string }[]).map(({ key, label, type, placeholder }) => (
                  <div key={key} className={styles.editCampo}>
                    <label className={styles.editLabel}>{label}</label>
                    <input className={styles.editInput} type={type} placeholder={placeholder} value={form[key]} onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))} />
                  </div>
                ))}
                <button className={styles.btnGuardar} onClick={handleSave} disabled={saving}>
                  <Save size={13} /> {saving ? 'Guardando…' : 'Guardar cambios'}
                </button>
              </div>
            ) : (
              <div className={styles.infoList}>
                <InfoRow icon={Users}    label="Usuario"      value={alumno.username} />
                <InfoRow icon={Users}    label="Nombre"       value={String(ext.full_name ?? '')} />
                <InfoRow icon={Phone}    label="Teléfono"     value={String(ext.phone ?? '')} />
                <InfoRow icon={Mail}     label="Email"        value={String(ext.email_contact ?? '')} />
                <InfoRow icon={MapPin}   label="Ciudad"       value={String(ext.city ?? '')} />
                <InfoRow icon={Calendar} label="Alta"         value={fmt(alumno.created_at)} />
                <InfoRow icon={Shield}   label="Acceso hasta" value={fmt(alumno.access_until)} />
                <InfoRow icon={Target}   label="Fecha examen" value={ext.exam_date ? fmt(String(ext.exam_date) + 'T12:00:00') : null} />
                <InfoRow icon={Euro}     label="Precio/mes"   value={ext.monthly_price ? `${ext.monthly_price} €` : null} />
              </div>
            )}
          </div>
        </div>

        <div className={styles.detalleRight}>
          <div className={styles.detalleKpisGrid}>
            <div className={styles.detalleKpi}>
              <span className={styles.detalleKpiVal} style={{ color: scoreColor(statsAlumno?.nota) }}>
                {statsAlumno?.nota != null ? `${statsAlumno.nota}%` : '—'}
              </span>
              <span className={styles.detalleKpiLabel}>Nota media</span>
            </div>
            <div className={styles.detalleKpi}><span className={styles.detalleKpiVal}>{statsAlumno?.sesiones ?? 0}</span><span className={styles.detalleKpiLabel}>Sesiones</span></div>
            <div className={styles.detalleKpi}><span className={styles.detalleKpiVal}>{statsAlumno?.fallos ?? 0}</span><span className={styles.detalleKpiLabel}>Fallos</span></div>
            <div className={styles.detalleKpi}>
              <span className={styles.detalleKpiVal} style={{ color: statsAlumno?.enRiesgo ? '#DC2626' : '#059669' }}>
                {statsAlumno?.enRiesgo ? 'En riesgo' : 'Activo'}
              </span>
              <span className={styles.detalleKpiLabel}>Estado</span>
            </div>
          </div>
          {statsAlumno?.enRiesgo && (
            <div className={styles.detalleAlerta}><AlertTriangle size={14} /> Lleva {statsAlumno.diasInactivo ?? '?'} días sin estudiar.</div>
          )}
          {ext.exam_date && (() => {
            const dias = Math.ceil((new Date(String(ext.exam_date)).getTime() - new Date().getTime()) / 86400000)
            if (dias < 0) return null
            return (
              <div className={styles.detalleExamen}>
                <Target size={14} />
                <div><span className={styles.detalleExamenNum}>{dias}</span><span className={styles.detalleExamenLabel}> días para el examen</span></div>
              </div>
            )
          })()}
        </div>
      </div>
    </div>
  )
}

// ── ProfesorDetallePanel ───────────────────────────────────────────────────
function ProfesorDetallePanel({ profesor, onBack }: { profesor: StudentProfile; onBack: () => void }) {
  const ext = profesor.extended ?? {}
  return (
    <div className={styles.detallePanel}>
      <div className={styles.detallePanelHead}>
        <button className={styles.btnBack} onClick={onBack}><ChevronLeft size={16} /> Volver</button>
        <div className={styles.detalleAvatar} style={{ background: '#7C3AED22', color: '#7C3AED' }}>
          {(String(ext.full_name ?? '') || profesor.username)[0]!.toUpperCase()}
        </div>
        <div className={styles.detalleTitleWrap}>
          <h2 className={styles.detalleTitle}>{String(ext.full_name ?? '') || profesor.username}</h2>
          <span className={styles.detalleUsername}>@{profesor.username} · {profesor.role}</span>
        </div>
      </div>
      <div className={styles.detalleCard} style={{ maxWidth: 480 }}>
        <h3 className={styles.detalleCardTitle}>Datos de contacto</h3>
        <div className={styles.infoList}>
          <InfoRow icon={Users}    label="Usuario"   value={profesor.username} />
          <InfoRow icon={Users}    label="Nombre"    value={String(ext.full_name    ?? '')} />
          <InfoRow icon={Phone}    label="Teléfono"  value={String(ext.phone        ?? '')} />
          <InfoRow icon={Mail}     label="Email"     value={String(ext.email_contact ?? '')} />
          <InfoRow icon={BookOpen} label="Bio"       value={String(ext.bio          ?? '')} />
          <InfoRow icon={Calendar} label="Alta"      value={fmt(profesor.created_at)} />
        </div>
        {!ext.full_name && !ext.phone && !ext.email_contact && (
          <p className={styles.emptyExtended}>Este profesor aún no ha completado su perfil.</p>
        )}
      </div>
    </div>
  )
}

// ── AlumnosTable ───────────────────────────────────────────────────────────
function AlumnosTable({ stats, academyProfiles, onAlumnoClick }: {
  stats:           Stats
  academyProfiles: { studentProfiles: StudentProfile[]; staffProfiles: StudentProfile[] }
  onAlumnoClick:   (a: AlumnoEnriquecido) => void
}) {
  const [sortBy,  setSortBy]  = useState<'nota' | 'sesiones'>('nota')
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc')
  const [filtro,  setFiltro]  = useState('todos')

  const todos = useMemo<AlumnoEnriquecido[]>(() => {
    const spMap: Record<string, StudentProfile> = {}
    for (const sp of academyProfiles.studentProfiles) spMap[sp.id] = sp
    return stats.bySubject.flatMap(sub =>
      sub.alumnosConNota.map(a => ({
        ...a,
        subjectName:   sub.name,
        subjectColor:  sub.color ?? '#6B7280',
        enRiesgo:      sub.alumnosEnRiesgo.some(r => r.id === a.id),
        diasInactivo:  sub.alumnosEnRiesgo.find(r => r.id === a.id)?.diasInactivo ?? null,
        diasRestantes: sub.alumnosPorExpirar.find(r => r.id === a.id)?.diasRestantes ?? null,
        extended:      spMap[a.id]?.extended ?? null,
        access_until:  spMap[a.id]?.access_until ?? null,
        created_at:    spMap[a.id]?.created_at ?? null,
      }))
    )
  }, [stats, academyProfiles])

  const filtrados = useMemo(() => {
    const arr = filtro === 'riesgo'  ? todos.filter(a => a.enRiesgo)
              : filtro === 'activos' ? todos.filter(a => !a.enRiesgo && a.sesiones > 0)
              : [...todos]
    return arr.sort((a, b) => {
      const va = (a as any)[sortBy] ?? -1, vb = (b as any)[sortBy] ?? -1
      return sortDir === 'desc' ? vb - va : va - vb
    })
  }, [todos, sortBy, sortDir, filtro])

  const handleSort = (col: 'nota' | 'sesiones') => {
    if (sortBy === col) setSortDir(d => d === 'desc' ? 'asc' : 'desc')
    else { setSortBy(col); setSortDir('desc') }
  }

  const SortBtn = ({ col, label }: { col: 'nota' | 'sesiones'; label: string }) => (
    <button className={styles.sortBtn} onClick={() => handleSort(col)}>
      {label} <ArrowUpDown size={10} style={{ opacity: sortBy === col ? 1 : 0.4 }} />
    </button>
  )

  return (
    <div className={styles.alumnosSection}>
      <div className={styles.alumnosFiltros}>
        {[
          { id: 'todos',   label: `Todos (${todos.length})` },
          { id: 'riesgo',  label: `⚠ Riesgo (${todos.filter(a => a.enRiesgo).length})` },
          { id: 'activos', label: `Activos (${todos.filter(a => a.sesiones > 0).length})` },
        ].map(f => (
          <button key={f.id} className={[styles.filtroBtn, filtro === f.id ? styles.filtroBtnActive : ''].join(' ')} onClick={() => setFiltro(f.id)}>{f.label}</button>
        ))}
      </div>
      <div className={styles.alumnosTable}>
        <div className={styles.alumnosTableHead}>
          <span>Alumno</span><span>Asignatura</span>
          <SortBtn col="nota"     label="Nota" />
          <SortBtn col="sesiones" label="Sesiones" />
          <span>Estado</span><span />
        </div>
        {filtrados.length === 0 ? <p className={styles.empty}>Sin alumnos</p> : filtrados.map(a => {
          const mascota = MASCOTAS[String(a.extended?.mascota ?? '')]
          const nombre  = String(a.extended?.full_name ?? '') || a.username
          const color   = scoreColor(a.nota)
          return (
            <div key={a.id} className={styles.alumnoRow} onClick={() => onAlumnoClick(a)}>
              <div className={styles.alumnoNameCell}>
                <div className={styles.alumnoAvatarSm} style={{ background: color + '22', color }}>
                  {mascota ? mascota.emoji : nombre[0]!.toUpperCase()}
                </div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: '0.82rem', color: 'var(--ink)' }}>{nombre}</div>
                  {a.extended?.full_name && <div style={{ fontSize: '0.68rem', color: 'var(--ink-muted)' }}>@{a.username}</div>}
                </div>
              </div>
              <div className={styles.alumnoSubCell}>
                <div className={styles.alumnoDot} style={{ background: a.subjectColor }} />
                <span>{a.subjectName}</span>
              </div>
              <span style={{ color, fontWeight: 700, fontSize: '0.88rem' }}>{a.nota !== null ? `${a.nota}%` : '—'}</span>
              <span style={{ fontSize: '0.82rem', color: 'var(--ink-muted)' }}>{a.sesiones}</span>
              <span className={a.enRiesgo ? styles.estadoRiesgo : styles.estadoOk}>{a.enRiesgo ? `${a.diasInactivo ?? '?'}d inactivo` : 'Activo'}</span>
              <ArrowRight size={13} className={styles.alumnoArrow} />
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ── ProfesoresTable ────────────────────────────────────────────────────────
function ProfesoresTable({ staffProfiles, stats, onProfesorClick }: {
  staffProfiles:   StudentProfile[]
  stats:           Stats
  onProfesorClick: (p: StudentProfile) => void
}) {
  const profesores = useMemo(() => {
    const profStats = stats.bySubject.flatMap(sub => sub.profesores.map(p => ({ ...p, subjectName: sub.name, subjectColor: sub.color })))
    return staffProfiles.filter(p => p.role === 'profesor').map(p => ({ ...p, stats: profStats.find(s => s.id === p.id) ?? null }))
  }, [staffProfiles, stats])

  if (!profesores.length) return <p className={styles.empty}>No hay profesores registrados en esta academia.</p>

  const now    = new Date()
  const act    = stats.profesorActivity
  const fmtDias = (iso: string) => {
    const dias = Math.floor((now.getTime() - new Date(iso).getTime()) / 86400000)
    if (dias === 0) return 'Hoy'
    if (dias === 1) return 'Ayer'
    if (dias < 30)  return `Hace ${dias}d`
    return `Hace ${Math.round(dias/30)}m`
  }

  return (
    <div className={styles.profesoresGrid}>
      {profesores.map(p => {
        const ext        = p.extended ?? {}
        const nombre     = String(ext.full_name ?? '') || p.username
        const lastAviso  = act?.lastAvisoByProfesor[p.id]
        const totalAvisos= act?.totalAvisosByProfesor[p.id] ?? 0
        const nAlumnos   = p.stats?.alumnos ?? 0
        const nota       = p.stats?.notaMedia ?? null
        const sinActividad = lastAviso
          ? Math.floor((now.getTime() - new Date(lastAviso.created_at).getTime()) / 86400000) > 14
          : true

        return (
          <div key={p.id} className={styles.profeCard}
            style={{
              borderTop: `3px solid ${sinActividad ? '#DC2626' : '#7C3AED'}`,
              boxShadow: sinActividad
                ? '0 4px 16px rgba(220,38,38,0.1)'
                : '0 4px 16px rgba(124,58,237,0.1)',
            }}
            onClick={() => onProfesorClick(p)}>

            {/* Cabecera */}
            <div className={styles.profeCardHead}>
              <div className={styles.profeAvatar} style={{
                background: sinActividad ? 'rgba(220,38,38,0.1)' : 'rgba(124,58,237,0.1)',
                color:      sinActividad ? '#DC2626' : '#7C3AED',
              }}>
                {nombre[0]!.toUpperCase()}
              </div>
              <div className={styles.profeInfo}>
                <span className={styles.profeNombre}>{nombre}</span>
                {ext.full_name && <span className={styles.profeUsername}>@{p.username}</span>}
              </div>
              {sinActividad && (
                <span className={styles.profeAlerta}>Sin actividad</span>
              )}
            </div>

            {/* Asignatura */}
            {p.stats && (
              <div className={styles.profeAsig}>
                <div className={styles.alumnoDot} style={{background: p.stats.subjectColor}}/>
                <span>{p.stats.subjectName}</span>
              </div>
            )}

            {/* KPIs */}
            <div className={styles.profeKpis}>
              <div className={styles.profeKpi}>
                <span className={styles.profeKpiVal}>{nAlumnos}</span>
                <span className={styles.profeKpiLabel}>Alumnos</span>
              </div>
              <div className={styles.profeKpi}>
                <span className={styles.profeKpiVal} style={{color: scoreColor(nota)}}>{nota !== null ? `${nota}%` : '—'}</span>
                <span className={styles.profeKpiLabel}>Nota media</span>
              </div>
              <div className={styles.profeKpi}>
                <span className={styles.profeKpiVal}>{totalAvisos}</span>
                <span className={styles.profeKpiLabel}>Avisos</span>
              </div>
            </div>

            {/* Último aviso */}
            <div className={styles.profeUltimoAviso}>
              <Megaphone size={11} style={{flexShrink:0, color: sinActividad ? '#DC2626' : 'var(--ink-subtle)'}}/>
              {lastAviso ? (
                <span style={{color: sinActividad ? '#DC2626' : 'var(--ink-muted)'}}>
                  {fmtDias(lastAviso.created_at)} — <em>{lastAviso.title.slice(0,40)}{lastAviso.title.length>40?'…':''}</em>
                </span>
              ) : (
                <span style={{color:'#DC2626'}}>Sin avisos publicados</span>
              )}
            </div>
          </div>
        )
      })}
    </div>
  )
}

// ── RentabilidadCard ───────────────────────────────────────────────────────
function RentabilidadCard({ stats, studentProfiles }: { stats: Stats; studentProfiles: StudentProfile[] }) {
  const preciosReales = studentProfiles.filter(p => p.extended?.monthly_price).map(p => parseFloat(String(p.extended!.monthly_price)))
  const mrrReal   = preciosReales.length > 0 ? preciosReales.reduce((a, b) => a + b, 0) : null
  const sinPrecio = studentProfiles.filter(p => !p.extended?.monthly_price).length
  const [precioBase,  setPrecioBase]  = useState('')
  const [editando,    setEditando]    = useState(false)
  const [inputPrecio, setInputPrecio] = useState('')
  const mrr       = mrrReal ?? (precioBase ? stats.totalAlumnos * parseFloat(precioBase) : null)
  const mrrRiesgo = precioBase ? stats.totalEnRiesgo * parseFloat(precioBase) : null

  return (
    <div className={styles.rentCard}>
      <div className={styles.rentHeader}>
        <h3 className={styles.rentTitle}><Euro size={14} /> Rentabilidad estimada</h3>
        <button className={styles.rentEditBtn} onClick={() => { setEditando(v => !v); setInputPrecio(precioBase) }}>
          {editando ? 'Cancelar' : '+ Precio base'}
        </button>
      </div>
      {mrrReal !== null && (
        <div className={styles.rentInfo}>
          <strong>{mrrReal.toLocaleString('es-ES', { minimumFractionDigits: 0 })} €/mes</strong> calculados desde los precios individuales de {preciosReales.length} alumno{preciosReales.length !== 1 ? 's' : ''}.
          {sinPrecio > 0 && ` ${sinPrecio} alumno${sinPrecio !== 1 ? 's' : ''} sin precio asignado.`}
        </div>
      )}
      {editando && (
        <div className={styles.rentForm}>
          <span className={styles.rentFormLabel}>Precio base para alumnos sin precio individual (€/mes)</span>
          <input type="number" className={styles.rentInput} value={inputPrecio} onChange={e => setInputPrecio(e.target.value)} placeholder="ej: 89" min="0" autoFocus />
          <button className={styles.rentGuardar} onClick={() => { setPrecioBase(inputPrecio); setEditando(false) }}>Aplicar</button>
        </div>
      )}
      {mrr !== null && (
        <div className={styles.rentKpis}>
          <div className={styles.rentKpi}><span className={styles.rentKpiVal} style={{ color: '#059669' }}>{mrr.toLocaleString('es-ES')} €</span><span className={styles.rentKpiLabel}>MRR</span></div>
          <div className={styles.rentKpi}><span className={styles.rentKpiVal}>{stats.totalAlumnos}</span><span className={styles.rentKpiLabel}>Alumnos</span></div>
          <div className={styles.rentKpi}>
            <span className={styles.rentKpiVal} style={{ color: '#DC2626' }}>
              -{((mrrRiesgo ?? 0) + (sinPrecio > 0 && precioBase ? sinPrecio * parseFloat(precioBase) : 0)).toLocaleString('es-ES')} €
            </span>
            <span className={styles.rentKpiLabel}>En riesgo</span>
          </div>
          <div className={styles.rentKpi}><span className={styles.rentKpiVal} style={{ color: '#059669' }}>{(mrr * 12).toLocaleString('es-ES')} €</span><span className={styles.rentKpiLabel}>ARR estimado</span></div>
        </div>
      )}
      {mrr === null && !editando && <p className={styles.rentSub}>Asigna precios individuales desde el perfil de cada alumno, o introduce un precio base para todos.</p>}
    </div>
  )
}

// ── ComunicacionPanel ────────────────────────────────────────────────────────
function ComunicacionPanel({ currentUser, profiles, mensajes, onDelete }: {
  currentUser: CurrentUser | null
  profiles:    ProfileSimple[]
  mensajes:    DirectMessage[]
  onDelete:    (id: string) => void
}) {
  const [modo,        setModo]        = useState<'individual' | 'masivo'>('individual')
  const [alumnoId,    setAlumnoId]    = useState('')
  const [texto,       setTexto]       = useState('')
  const [enviando,    setEnviando]    = useState(false)
  const [enviado,     setEnviado]     = useState(false)
  const [expandedId,  setExpandedId]  = useState<string | null>(null)

  const alumnos = profiles.filter(p => p.role === 'alumno')

  const handleEnviar = async () => {
    if (!texto.trim()) return
    if (modo === 'individual' && !alumnoId) return
    setEnviando(true)
    try {
      const targets = modo === 'masivo' ? alumnos.map(a => a.id) : [alumnoId]
      for (const toId of targets) {
        await supabase.from('direct_messages').insert({
          from_id:    currentUser?.id,
          to_id:      toId,
          academy_id: currentUser?.academy_id,
          subject_id: currentUser?.subject_id ?? null,
          body:       texto.trim(),
        })
        // Notificación al alumno
        await supabase.from('notifications').insert({
          user_id: toId,
          type:    'mensaje_director',
          title:   'Mensaje de tu director',
          body:    texto.trim().slice(0, 100),
          link:    '/',
        })
      }
      setEnviado(true)
      setTexto('')
      if (modo === 'individual') setAlumnoId('')
      setTimeout(() => setEnviado(false), 2000)
    } finally {
      setEnviando(false)
    }
  }

  // Mensajes enviados — más recientes primero
  const enviados = [...mensajes].sort((a,b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())

  const fmtFecha = (iso: string) => new Date(iso).toLocaleDateString('es-ES', { day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit' })

  return (
    <div className={styles.comunicacionWrap}>

      {/* Formulario de envío */}
      <div className={styles.comunicacionForm}>
        {/* Toggle individual / masivo */}
        <div className={styles.comunicacionModoTabs}>
          <button
            className={[styles.comunicacionModoTab, modo==='individual' ? styles.comunicacionModoTabActive : ''].join(' ')}
            onClick={() => setModo('individual')}>
            <MessageSquare size={13}/> Mensaje individual
          </button>
          <button
            className={[styles.comunicacionModoTab, modo==='masivo' ? styles.comunicacionModoTabActive : ''].join(' ')}
            onClick={() => setModo('masivo')}>
            <Users size={13}/> Mensaje a toda la academia
          </button>
        </div>

        {/* Selector de alumno */}
        {modo === 'individual' && (
          <div className={styles.comunicacionField}>
            <label className={styles.comunicacionLabel}>Destinatario</label>
            <select
              className={styles.comunicacionSelect}
              value={alumnoId}
              onChange={e => setAlumnoId(e.target.value)}>
              <option value="">Selecciona un alumno...</option>
              {alumnos.map(a => (
                <option key={a.id} value={a.id}>{a.username}</option>
              ))}
            </select>
          </div>
        )}

        {modo === 'masivo' && (
          <div className={styles.comunicacionMasivoInfo}>
            <Users size={13} style={{color:'#0891B2', flexShrink:0}}/>
            <span>El mensaje llegará a <strong>{alumnos.length} alumnos</strong> de la academia</span>
          </div>
        )}

        {/* Textarea */}
        <div className={styles.comunicacionField}>
          <label className={styles.comunicacionLabel}>Mensaje</label>
          <textarea
            className={styles.comunicacionTextarea}
            placeholder={modo === 'masivo'
              ? 'Escribe un aviso para todos tus alumnos...'
              : 'Escribe tu mensaje...'}
            value={texto}
            onChange={e => setTexto(e.target.value)}
            rows={4}
          />
        </div>

        <div className={styles.comunicacionFormFoot}>
          <span className={styles.comunicacionHint}>
            El alumno lo verá en su tablón → Mensajes
          </span>
          <button
            className={styles.comunicacionBtnEnviar}
            onClick={handleEnviar}
            disabled={enviando || !texto.trim() || (modo==='individual' && !alumnoId)}>
            {enviado
              ? <><Check size={14}/> Enviado</>
              : enviando
                ? <><RefreshCw size={14} className={styles.spinner}/> Enviando...</>
                : <><Send size={14}/> {modo === 'masivo' ? `Enviar a ${alumnos.length} alumnos` : 'Enviar'}</>
            }
          </button>
        </div>
      </div>

      {/* Historial de mensajes enviados */}
      {enviados.length > 0 && (
        <div className={styles.comunicacionHistorial}>
          <div className={styles.comunicacionHistorialTitle}>
            <CornerDownLeft size={13}/> Mensajes enviados ({enviados.length})
          </div>
          <div className={styles.comunicacionMensajesList}>
            {enviados.map(m => {
              const dest    = profiles.find(p => p.id === m.to_id)
              const expanded = expandedId === m.id
              return (
                <div key={m.id} className={styles.comunicacionMensajeCard}>
                  <button
                    className={styles.comunicacionMensajeHeader}
                    onClick={() => setExpandedId(expanded ? null : m.id)}>
                    <div className={styles.comunicacionMensajeAvatar}>
                      {(dest?.username ?? '?')[0]!.toUpperCase()}
                    </div>
                    <div className={styles.comunicacionMensajeInfo}>
                      <span className={styles.comunicacionMensajeDest}>{dest?.username ?? 'Alumno'}</span>
                      <span className={styles.comunicacionMensajePreview}>
                        {expanded ? '▲ Ocultar' : m.body.slice(0, 60) + (m.body.length > 60 ? '…' : '')}
                      </span>
                    </div>
                    <div className={styles.comunicacionMensajeMeta}>
                      <span className={styles.comunicacionMensajeFecha}>{fmtFecha(m.created_at)}</span>
                      {m.reply_body && (
                        <span className={styles.comunicacionMensajeReplied}>✓ Respondido</span>
                      )}
                    </div>
                  </button>

                  {expanded && (
                    <div className={styles.comunicacionMensajeBody}>
                      <div className={styles.inboxMsgBubbleProfe}>
                        <span className={styles.inboxMsgLabel}>Tú enviaste</span>
                        <p className={styles.inboxMsgText}>{m.body}</p>
                      </div>
                      {m.reply_body && (
                        <div className={styles.inboxMsgBubbleAlumno}>
                          <div className={styles.inboxMsgAlumnoHead}>
                            <span className={styles.inboxMsgLabel} style={{color:'#059669'}}>{dest?.username ?? 'Alumno'} respondió</span>
                            <span className={styles.inboxMsgFecha}>{m.reply_at ? fmtFecha(m.reply_at) : ''}</span>
                          </div>
                          <p className={styles.inboxMsgText}>{m.reply_body}</p>
                        </div>
                      )}
                      <button className={styles.inboxMsgBtnEliminar} onClick={() => onDelete(m.id)}>
                        <Trash2 size={11}/> Eliminar
                      </button>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}

// ── RetencionPanel ────────────────────────────────────────────────────────
function RetencionPanel({ profiles }: { profiles: ProfileSimple[] }) {
  const now      = new Date()
  const alumnos  = profiles.filter(p => p.role === 'alumno')

  const fmtDias = (d: number) => d < 30 ? `${d}d` : d < 365 ? `${Math.round(d/30)}m` : `${(d/365).toFixed(1)}a`

  // Enriquecer cada alumno
  const enriquecidos = alumnos.map(a => {
    const inicio       = a.created_at ? new Date(a.created_at) : null
    const fin          = a.access_until ? new Date(a.access_until) : null
    const diasEnAcad   = inicio ? Math.floor((now.getTime() - inicio.getTime()) / 86400000) : null
    const diasRestantes= fin ? Math.ceil((fin.getTime() - now.getTime()) / 86400000) : null
    const expirado     = fin ? fin < now : false
    const mesAlta      = inicio ? `${inicio.getFullYear()}-${String(inicio.getMonth()+1).padStart(2,'0')}` : null
    return { ...a, diasEnAcad, diasRestantes, expirado, mesAlta, inicio, fin }
  })

  // KPIs
  const activos      = enriquecidos.filter(a => !a.expirado)
  const expirados    = enriquecidos.filter(a => a.expirado)
  const nuevos30d    = enriquecidos.filter(a => a.diasEnAcad !== null && a.diasEnAcad <= 30)
  const fieles       = enriquecidos.filter(a => a.diasEnAcad !== null && a.diasEnAcad >= 90 && !a.expirado)
  const mediaPerma   = activos.length
    ? Math.round(activos.reduce((s,a) => s + (a.diasEnAcad ?? 0), 0) / activos.length)
    : 0
  const vencen15d    = activos.filter(a => a.diasRestantes !== null && a.diasRestantes <= 15)
  const tasaActivos  = alumnos.length ? Math.round((activos.length / alumnos.length) * 100) : 0

  // Cohorts por mes de alta
  const cohorts = Array.from(
    enriquecidos.reduce((map, a) => {
      if (!a.mesAlta) return map
      const entry = map.get(a.mesAlta) ?? { mes: a.mesAlta, total: 0, activos: 0 }
      entry.total++
      if (!a.expirado) entry.activos++
      map.set(a.mesAlta, entry)
      return map
    }, new Map<string, {mes:string; total:number; activos:number}>())
  ).map(([,v]) => v).sort((a,b) => a.mes.localeCompare(b.mes))

  const MESES_ES = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic']
  const fmtMes = (ym: string) => {
    const [y, m] = ym.split('-')
    return `${MESES_ES[parseInt(m!)-1]} ${y}`
  }

  return (
    <div className={styles.retencionWrap}>

      {/* KPIs */}
      <div className={styles.retencionKpis}>
        <div className={styles.retencionKpi}>
          <div className={styles.retencionKpiIcon} style={{background:'rgba(5,150,105,0.1)',color:'#059669'}}>
            <Users size={18} strokeWidth={1.8}/>
          </div>
          <div className={styles.retencionKpiVal} style={{color:'#059669'}}>{activos.length}</div>
          <div className={styles.retencionKpiLabel}>Alumnos activos</div>
          <div className={styles.retencionKpiSub}>{tasaActivos}% del total</div>
        </div>
        <div className={styles.retencionKpi}>
          <div className={styles.retencionKpiIcon} style={{background:'rgba(37,99,235,0.1)',color:'#2563EB'}}>
            <TrendingUp size={18} strokeWidth={1.8}/>
          </div>
          <div className={styles.retencionKpiVal}>{fmtDias(mediaPerma)}</div>
          <div className={styles.retencionKpiLabel}>Permanencia media</div>
          <div className={styles.retencionKpiSub}>Alumnos activos</div>
        </div>
        <div className={styles.retencionKpi}>
          <div className={styles.retencionKpiIcon} style={{background:'rgba(124,58,237,0.1)',color:'#7C3AED'}}>
            <Star size={18} strokeWidth={1.8}/>
          </div>
          <div className={styles.retencionKpiVal} style={{color:'#7C3AED'}}>{fieles.length}</div>
          <div className={styles.retencionKpiLabel}>Alumnos fieles</div>
          <div className={styles.retencionKpiSub}>Más de 3 meses activos</div>
        </div>
        <div className={styles.retencionKpi} style={nuevos30d.length > 0 ? {borderColor:'rgba(8,145,178,0.3)'} : {}}>
          <div className={styles.retencionKpiIcon} style={{background:'rgba(8,145,178,0.1)',color:'#0891B2'}}>
            <UserPlus size={18} strokeWidth={1.8}/>
          </div>
          <div className={styles.retencionKpiVal} style={{color:'#0891B2'}}>{nuevos30d.length}</div>
          <div className={styles.retencionKpiLabel}>Nuevos este mes</div>
          <div className={styles.retencionKpiSub}>Últimos 30 días</div>
        </div>
      </div>

      {/* Alerta vencen pronto */}
      {vencen15d.length > 0 && (
        <div className={styles.retencionAlerta}>
          <AlertTriangle size={14} style={{color:'#DC2626',flexShrink:0}}/>
          <span><strong>{vencen15d.length} alumno{vencen15d.length!==1?'s':''}</strong> pierde{vencen15d.length===1?'':'n'} acceso en menos de 15 días — {vencen15d.map(a=>a.username).join(', ')}</span>
        </div>
      )}

      {/* Cohorts por mes de alta */}
      <div className={styles.retencionSection}>
        <div className={styles.retencionSectionTitle}>
          <Calendar size={14}/> Cohortes de registro
        </div>
        <div className={styles.cohortGrid}>
          {cohorts.map((c, i) => {
            const pct = c.total ? Math.round((c.activos / c.total) * 100) : 0
            return (
              <div key={i} className={styles.cohortCard}>
                <div className={styles.cohortMes}>{fmtMes(c.mes)}</div>
                <div className={styles.cohortStats}>
                  <span className={styles.cohortNum}>{c.activos}<span>/{c.total}</span></span>
                  <span className={styles.cohortLabel}>activos</span>
                </div>
                <div className={styles.cohortBar}>
                  <div className={styles.cohortBarFill} style={{
                    width: `${pct}%`,
                    background: pct >= 80 ? 'linear-gradient(90deg,#059669,#34d399)' :
                                pct >= 50 ? 'linear-gradient(90deg,#D97706,#fbbf24)' :
                                            'linear-gradient(90deg,#DC2626,#f87171)',
                  }}/>
                </div>
                <div className={styles.cohortPct} style={{
                  color: pct >= 80 ? '#059669' : pct >= 50 ? '#D97706' : '#DC2626'
                }}>{pct}%</div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Cards de alumnos con permanencia */}
      <div className={styles.retencionSection}>
        <div className={styles.retencionSectionTitle}>
          <Clock size={14}/> Tiempo en academia por alumno
        </div>
        <div className={styles.retencionCardsGrid}>
          {[...enriquecidos].sort((a,b) => (b.diasEnAcad??0) - (a.diasEnAcad??0)).map((a, i) => {
            const dias  = a.diasEnAcad ?? 0
            const pct   = Math.min(100, Math.round((dias / 365) * 100))
            const color = a.expirado ? '#DC2626' : dias >= 90 ? '#059669' : '#0891B2'
            const glow  = a.expirado ? 'rgba(220,38,38,0.13)' : dias >= 90 ? 'rgba(5,150,105,0.13)' : 'rgba(8,145,178,0.13)'
            const gradStart = a.expirado ? '#DC2626' : dias >= 90 ? '#059669' : '#0891B2'
            const gradEnd   = a.expirado ? '#f87171' : dias >= 90 ? '#34d399' : '#38bdf8'
            const etiqueta  = a.expirado ? 'Expirado' : dias >= 90 ? 'Fiel' : dias >= 30 ? 'Regular' : 'Nuevo'
            return (
              <div key={i} className={styles.retencionCard}
                style={{
                  border: `2px solid ${color}66`,
                  boxShadow: `0 4px 16px ${glow}, 0 1px 3px rgba(0,0,0,0.04)`
                }}>
                {/* Cabecera */}
                <div className={styles.retencionCardHead}>
                  <div className={styles.retencionCardAvatar} style={{background:`${color}18`, color}}>
                    {a.username[0]!.toUpperCase()}
                  </div>
                  <div className={styles.retencionCardInfo}>
                    <span className={styles.retencionCardNombre}>{a.username}</span>
                    <span className={styles.retencionCardEtiqueta} style={{color, background:`${color}12`}}>
                      {etiqueta}
                    </span>
                  </div>
                </div>
                {/* Permanencia */}
                <div className={styles.retencionCardDias} style={{color}}>
                  {fmtDias(dias)}
                  <span>en academia</span>
                </div>
                {/* Barra de progreso animada */}
                <div className={styles.retencionCardBar}>
                  <div className={styles.retencionCardBarFill} style={{
                    width: `${pct}%`,
                    background: `linear-gradient(90deg, ${gradStart}, ${gradEnd})`,
                    boxShadow: `0 0 6px ${color}88`,
                  }}/>
                </div>
                {/* Acceso restante */}
                <div className={styles.retencionCardExpira}>
                  {a.expirado
                    ? <span style={{color:'#DC2626', fontWeight:700}}>✕ Sin acceso</span>
                    : a.diasRestantes !== null
                      ? <><span style={{color, fontWeight:700}}>{a.diasRestantes}d</span> de acceso restante</>
                      : '—'
                  }
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

// ── AlertasPanel ───────────────────────────────────────────────────────────
function AlertasPanel({ stats, onAlumnoClick }: { stats: Stats; onAlumnoClick: (a: any) => void }) {
  const todos   = stats.bySubject.flatMap(sub => sub.alumnosEnRiesgo.map(a => ({ ...a, subjectName: sub.name, subjectColor: sub.color }))).sort((a, b) => (b.diasInactivo ?? 0) - (a.diasInactivo ?? 0))
  const expiran = stats.bySubject.flatMap(sub => sub.alumnosPorExpirar.map(a => ({ ...a, subjectName: sub.name, subjectColor: sub.color }))).sort((a, b) => a.diasRestantes - b.diasRestantes)

  if (!todos.length && !expiran.length) return (
    <div className={styles.riesgoOk}><CheckCircle size={18} style={{ color: '#059669' }} /><span>Sin alertas activas — todo en orden</span></div>
  )

  const Item = ({ a, badge }: { a: any; badge: React.ReactNode }) => (
    <div className={styles.riesgoItem} onClick={() => onAlumnoClick({ ...a, enRiesgo: true })}>
      <div className={styles.riesgoAvatar}>{String(a.username)[0]!.toUpperCase()}</div>
      <div className={styles.riesgoBody}>
        <span className={styles.riesgoUsername}>{a.username}</span>
        <span className={styles.riesgoSub} style={{ color: a.subjectColor }}>{a.subjectName}</span>
      </div>
      {badge}
      <ArrowRight size={13} className={styles.alumnoArrow} />
    </div>
  )

  return (
    <div className={styles.riesgoWrap}>
      {todos.length > 0 && (
        <div className={styles.riesgoGrupo}>
          <div className={styles.riesgoGrupoTitle}><AlertTriangle size={13} style={{ color: '#DC2626' }} />{todos.length} alumno{todos.length !== 1 ? 's' : ''} sin actividad</div>
          {todos.map(a => <Item key={a.id} a={a} badge={<span className={styles.riesgoBadgeRed}>{a.diasInactivo ?? '?'}d inactivo</span>} />)}
        </div>
      )}
      {expiran.length > 0 && (
        <div className={styles.riesgoGrupo}>
          <div className={styles.riesgoGrupoTitle}><Clock size={13} style={{ color: '#D97706' }} />{expiran.length} acceso{expiran.length !== 1 ? 's' : ''} próximos a expirar</div>
          {expiran.map(a => <Item key={a.id} a={a} badge={<span className={styles.riesgoBadgeAmber}>Expira en {a.diasRestantes}d</span>} />)}
        </div>
      )}
    </div>
  )
}

// ── OnboardingChecklist ────────────────────────────────────────────────────
function OnboardingChecklist({ currentUser, stats }: { currentUser: CurrentUser | null; stats: Stats }) {
  const [dismissed, setDismissed] = useState(!!localStorage.getItem(`onboarding_dismissed_${currentUser?.id}`))
  const [hasCodigo, setHasCodigo] = useState(false)

  useEffect(() => {
    if (dismissed || !currentUser?.academy_id) return
    supabase.from('invite_codes').select('id', { count: 'exact', head: true }).eq('academy_id', currentUser.academy_id)
      .then(({ count }) => setHasCodigo((count ?? 0) > 0))
  }, [dismissed, currentUser?.academy_id])

  if (dismissed) return null

  const pasos = [
    { id: 'academia',   label: 'Academia creada',               done: true,                            icon: Rocket },
    { id: 'asignatura', label: 'Primera asignatura',            done: (stats?.bySubject?.length??0)>0, icon: BookMarked },
    { id: 'profesor',   label: 'Primer profesor',               done: (stats?.totalProfesores??0)>0,   icon: GraduationCap },
    { id: 'codigo',     label: 'Código de invitación generado', done: hasCodigo,                       icon: Key },
    { id: 'alumno',     label: 'Primer alumno registrado',      done: (stats?.totalAlumnos??0)>0,      icon: UserPlus },
    { id: 'sesion',     label: 'Primera sesión completada',     done: (stats?.sesiones30d??0)>0,       icon: Zap },
  ]
  const completados = pasos.filter(p => p.done).length
  if (completados === pasos.length) return null

  return (
    <div className={styles.onboarding}>
      <div className={styles.onboardingHead}>
        <div className={styles.onboardingTitle}><Rocket size={14} /> Configura tu academia <span className={styles.onboardingPct}>{completados}/{pasos.length}</span></div>
        <button className={styles.onboardingDismiss} onClick={() => { localStorage.setItem(`onboarding_dismissed_${currentUser?.id}`, '1'); setDismissed(true) }}><X size={13} /></button>
      </div>
      <div className={styles.onboardingBar}><div className={styles.onboardingBarFill} style={{ width: `${Math.round(completados/pasos.length*100)}%` }} /></div>
      <div className={styles.onboardingSteps}>
        {pasos.map(paso => {
          const Icon = paso.icon
          return (
            <div key={paso.id} className={[styles.onboardingStep, paso.done ? styles.onboardingStepDone : ''].join(' ')}>
              <div className={styles.onboardingStepIcon}>{paso.done ? <Check size={11} strokeWidth={2.5} /> : <Icon size={11} />}</div>
              <span className={styles.onboardingStepLabel}>{paso.label}</span>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ── exportarInforme ────────────────────────────────────────────────────────
function exportarInforme(stats: Stats, academyName: string | null | undefined, studentProfiles: StudentProfile[]) {
  const fecha         = new Date().toLocaleDateString('es-ES', { day: '2-digit', month: 'long', year: 'numeric' })
  const preciosReales = studentProfiles.filter(p => p.extended?.monthly_price).map(p => parseFloat(String(p.extended!.monthly_price)))
  const mrr           = preciosReales.length > 0 ? preciosReales.reduce((a, b) => a + b, 0) : null
  const enRiesgo      = stats.bySubject.flatMap(s => s.alumnosEnRiesgo)
  const porExpirar    = stats.bySubject.flatMap(s => s.alumnosPorExpirar)
  const spMap: Record<string, StudentProfile> = {}
  for (const sp of studentProfiles) spMap[sp.id] = sp
  const todosAlumnos = stats.bySubject.flatMap(sub =>
    sub.alumnosConNota.map(a => ({
      ...a,
      subjectName: sub.name,
      enRiesgo:    sub.alumnosEnRiesgo.some(r => r.id === a.id),
      examDate:    spMap[a.id]?.extended?.exam_date ?? null,
      fullName:    spMap[a.id]?.extended?.full_name ?? null,
    }))
  ).sort((a, b) => (b.nota ?? -1) - (a.nota ?? -1))
  const nc     = (n: number) => n >= 70 ? '#059669' : n >= 50 ? '#B45309' : '#DC2626'
  const maxSes = Math.max(...stats.semanas.map(s => s.sesiones), 1)
  const semanasHtml = stats.semanas.map(s => {
    const h = Math.round((s.sesiones/maxSes)*50)
    return `<div class="sem-bar-wrap">${s.sesiones>0?`<div class="sem-val">${s.sesiones}</div>`:''}<div class="sem-bar" style="height:${Math.max(h,2)}px"></div><div class="sem-label">${s.label}</div></div>`
  }).join('')

  const css = `*{box-sizing:border-box;margin:0;padding:0}body{font-family:-apple-system,'Segoe UI',sans-serif;color:#111;padding:2.5rem;max-width:860px;margin:0 auto;font-size:13px}.header{display:flex;justify-content:space-between;margin-bottom:2rem;padding-bottom:1.5rem;border-bottom:2px solid #111}.header-left h1{font-size:1.5rem;font-weight:800}h2{font-size:.7rem;font-weight:800;color:#6B7280;text-transform:uppercase;letter-spacing:.08em;margin:1.75rem 0 .75rem}.kpis{display:grid;grid-template-columns:repeat(6,1fr);gap:.6rem;margin-bottom:.5rem}.kpi{border:1px solid #E5E7EB;border-radius:10px;padding:.75rem .5rem;text-align:center}.kv{font-size:1.4rem;font-weight:800}.kl{font-size:.62rem;color:#6B7280;margin-top:.3rem;text-transform:uppercase}table{width:100%;border-collapse:collapse;margin-bottom:1rem}th{background:#F9FAFB;font-size:.7rem;font-weight:700;text-align:left;padding:.5rem .75rem;border-bottom:2px solid #E5E7EB;text-transform:uppercase;color:#374151}td{padding:.5rem .75rem;border-bottom:1px solid #F3F4F6;font-size:.78rem}.tag{display:inline-block;border-radius:4px;padding:.15rem .45rem;font-size:.65rem;font-weight:700}.tag-red{background:#FEF2F2;color:#DC2626}.tag-green{background:#ECFDF5;color:#059669}.tag-amber{background:#FFFBEB;color:#B45309}.alert-section{border:1px solid #FEE2E2;border-radius:10px;padding:1rem;background:#FFF5F5;margin-bottom:.5rem}.alert-title{font-size:.7rem;font-weight:800;color:#DC2626;text-transform:uppercase;margin-bottom:.5rem}.alert-row{display:flex;justify-content:space-between;padding:.3rem 0;border-bottom:1px solid #FEE2E2;font-size:.75rem}.alert-row:last-child{border:none}.semanas{display:grid;grid-template-columns:repeat(8,1fr);gap:.4rem;align-items:flex-end;height:60px;margin-bottom:.3rem}.sem-bar-wrap{display:flex;flex-direction:column;align-items:center;gap:.2rem;height:100%;justify-content:flex-end}.sem-bar{width:100%;border-radius:3px;background:#0891B2;min-height:2px}.sem-label{font-size:.55rem;color:#9CA3AF;text-align:center}.sem-val{font-size:.6rem;color:#374151;font-weight:700}.rent{display:grid;grid-template-columns:repeat(3,1fr);gap:.6rem}.rent-kpi{border:1px solid #E5E7EB;border-radius:10px;padding:.75rem 1rem}footer{margin-top:2.5rem;padding-top:1rem;border-top:1px solid #E5E7EB;display:flex;justify-content:space-between;color:#9CA3AF;font-size:.7rem}@media print{body{padding:1rem}@page{margin:1.5cm}}`

  const html = `<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><title>Informe ${academyName??'Academia'}</title><style>${css}</style></head><body>
  <div class="header"><div class="header-left"><h1>${academyName??'Academia'}</h1><p style="color:#6B7280;font-size:.8rem">Informe de dirección · Últimos 30 días</p></div><div style="text-align:right;color:#6B7280;font-size:.75rem"><strong>Generado el</strong> ${fecha}</div></div>
  <h2>Resumen</h2><div class="kpis"><div class="kpi"><div class="kv">${stats.totalAlumnos}</div><div class="kl">Alumnos</div></div><div class="kpi"><div class="kv" style="color:#059669">${stats.totalActivos}</div><div class="kl">Activos 7d</div></div><div class="kpi"><div class="kv">${stats.notaGlobal!==null?stats.notaGlobal+'%':'—'}</div><div class="kl">Nota media</div></div><div class="kpi"><div class="kv">${stats.sesiones30d}</div><div class="kl">Sesiones 30d</div></div><div class="kpi"><div class="kv" style="color:#DC2626">${stats.totalEnRiesgo}</div><div class="kl">En riesgo</div></div><div class="kpi"><div class="kv" style="color:#B45309">${stats.totalPorExpirar}</div><div class="kl">Expiran pronto</div></div></div>
  <h2>Actividad</h2><div class="semanas">${semanasHtml}</div>
  <h2>Por asignatura</h2><table><tr><th>Asignatura</th><th>Alumnos</th><th>Activos 7d</th><th>Nota media</th><th>Sesiones 30d</th><th>En riesgo</th><th>Expiran pronto</th></tr>${stats.bySubject.map(s=>`<tr><td><strong>${s.name}</strong></td><td>${s.totalAlumnos}</td><td>${s.alumnosActivos}</td><td style="font-weight:700;color:${nc(s.notaMedia??0)}">${s.notaMedia!==null?s.notaMedia+'%':'—'}</td><td>${s.sesiones30d}</td><td>${s.enRiesgo>0?`<span class="tag tag-red">${s.enRiesgo}</span>`:'—'}</td><td>${s.porExpirar>0?`<span class="tag tag-amber">${s.porExpirar}</span>`:'—'}</td></tr>`).join('')}</table>
  <h2>Alumnos</h2><table><tr><th>Alumno</th><th>Asignatura</th><th>Nota media</th><th>Sesiones</th><th>Estado</th><th>Fecha examen</th></tr>${todosAlumnos.map(a=>`<tr><td><strong>${a.fullName||a.username}</strong>${a.fullName?`<br><span style="color:#9CA3AF;font-size:.68rem">@${a.username}</span>`:''}</td><td>${a.subjectName}</td><td style="font-weight:700;color:${nc(a.nota??0)}">${a.nota!==null?a.nota+'%':'—'}</td><td>${a.sesiones}</td><td>${a.enRiesgo?'<span class="tag tag-red">En riesgo</span>':'<span class="tag tag-green">Activo</span>'}</td><td style="color:#6B7280">${a.examDate?new Date(String(a.examDate)).toLocaleDateString('es-ES',{day:'2-digit',month:'short',year:'numeric'}):'—'}</td></tr>`).join('')}</table>
  ${enRiesgo.length>0?`<h2>Alertas</h2><div class="alert-section"><div class="alert-title">⚠ ${enRiesgo.length} sin actividad</div>${enRiesgo.map(a=>`<div class="alert-row"><span>${a.username}</span><span style="color:#DC2626">${a.diasInactivo??'?'} días inactivo</span></div>`).join('')}</div>`:''}
  ${mrr!==null?`<h2>Rentabilidad</h2><div class="rent"><div class="rent-kpi"><div class="kv">${mrr.toLocaleString('es-ES')} €</div><div class="kl">MRR</div></div><div class="rent-kpi"><div class="kv">${(mrr*12).toLocaleString('es-ES')} €</div><div class="kl">ARR estimado</div></div><div class="rent-kpi"><div class="kv">${preciosReales.length}</div><div class="kl">Alumnos con precio</div></div></div>`:''}
  <footer><span>FrostFox Academy · Informe de dirección</span><span>${fecha}</span></footer></body></html>`

  const w = window.open('', '_blank'); if (!w) return
  w.document.write(html); w.document.close(); setTimeout(() => w.print(), 500)
}

// ── VencimientosPanel ─────────────────────────────────────────────────────
function VencimientosPanel({ profiles, onRenovar }: {
  profiles:  ProfileSimple[]
  onRenovar: (id: string, username: string) => void
}) {
  const now     = new Date()
  const alumnos = profiles.filter(p => p.role === 'alumno')

  const enriquecidos = alumnos
    .filter(a => a.access_until)
    .map(a => ({
      id:          a.id,
      username:    a.username,
      accessUntil: a.access_until!,
      dias:        Math.ceil((new Date(a.access_until!).getTime() - now.getTime()) / 86400000),
    }))
    .sort((a, b) => a.dias - b.dias)

  const expirados  = enriquecidos.filter(a => a.dias <= 0)
  const esta_semana = enriquecidos.filter(a => a.dias > 0 && a.dias <= 7)
  const este_mes   = enriquecidos.filter(a => a.dias > 7 && a.dias <= 30)
  const proximos   = enriquecidos.filter(a => a.dias > 30 && a.dias <= 90)
  const sin_acceso = alumnos.filter(a => !a.access_until)

  const fmtFecha = (iso: string) =>
    new Date(iso).toLocaleDateString('es-ES', { day:'2-digit', month:'short', year:'numeric' })

  const Grupo = ({ titulo, items, color, urgente }: {
    titulo: string; items: typeof enriquecidos; color: string; urgente?: boolean
  }) => {
    if (!items.length) return null
    return (
      <div className={styles.vencGrupo}>
        <div className={styles.vencGrupoTitulo} style={{color}}>
          <span className={styles.vencGrupoDot} style={{background:color}}/>
          {titulo}
          <span className={styles.vencGrupoCount}>{items.length}</span>
        </div>
        <div className={styles.vencCardsGrid}>
          {items.map(a => (
            <div key={a.id} className={styles.vencCard} style={{
              borderLeft: `3px solid ${color}`,
              boxShadow: urgente ? `0 4px 16px ${color}22` : undefined,
            }}>
              <div className={styles.vencCardHead}>
                <div className={styles.vencAvatar} style={{background:`${color}15`,color}}>
                  {a.username[0]!.toUpperCase()}
                </div>
                <div className={styles.vencInfo}>
                  <span className={styles.vencNombre}>{a.username}</span>
                  <span className={styles.vencFecha}>{a.dias <= 0 ? 'Expirado' : fmtFecha(a.accessUntil)}</span>
                </div>
                <div className={styles.vencDiasBadge} style={{background:`${color}15`,color}}>
                  {a.dias <= 0 ? `${Math.abs(a.dias)}d expirado` : `${a.dias}d`}
                </div>
              </div>
              <button className={styles.vencBtnRenovar} style={{'--vc':color} as React.CSSProperties}
                onClick={() => onRenovar(a.id, a.username)}>
                <RotateCcw size={11}/> Renovar acceso
              </button>
            </div>
          ))}
        </div>
      </div>
    )
  }

  const totalAlertas = expirados.length + esta_semana.length

  return (
    <div className={styles.vencWrap}>
      {/* KPIs resumen */}
      <div className={styles.vencKpis}>
        <div className={styles.vencKpi} style={{borderColor: expirados.length>0?'rgba(220,38,38,0.3)':undefined}}>
          <span className={styles.vencKpiVal} style={{color:expirados.length>0?'#DC2626':'var(--ink)'}}>{expirados.length}</span>
          <span className={styles.vencKpiLabel}>Expirados</span>
        </div>
        <div className={styles.vencKpi} style={{borderColor: esta_semana.length>0?'rgba(217,119,6,0.3)':undefined}}>
          <span className={styles.vencKpiVal} style={{color:esta_semana.length>0?'#D97706':'var(--ink)'}}>{esta_semana.length}</span>
          <span className={styles.vencKpiLabel}>Esta semana</span>
        </div>
        <div className={styles.vencKpi}>
          <span className={styles.vencKpiVal} style={{color:este_mes.length>0?'#D97706':'var(--ink)'}}>{este_mes.length}</span>
          <span className={styles.vencKpiLabel}>Este mes</span>
        </div>
        <div className={styles.vencKpi}>
          <span className={styles.vencKpiVal}>{proximos.length}</span>
          <span className={styles.vencKpiLabel}>En 30–90 días</span>
        </div>
      </div>

      {totalAlertas === 0 && expirados.length === 0 && (
        <div className={styles.vencOk}>
          <CheckCircle size={32} strokeWidth={1.4} style={{color:'#059669'}}/>
          <p>No hay accesos urgentes esta semana</p>
        </div>
      )}

      <Grupo titulo="Expirados — acción inmediata" items={expirados} color="#DC2626" urgente />
      <Grupo titulo="Expiran esta semana" items={esta_semana} color="#D97706" urgente />
      <Grupo titulo="Expiran este mes" items={este_mes} color="#F59E0B" />
      <Grupo titulo="Expiran en 30–90 días" items={proximos} color="#0891B2" />

      {sin_acceso.length > 0 && (
        <div className={styles.vencGrupo}>
          <div className={styles.vencGrupoTitulo} style={{color:'var(--ink-subtle)'}}>
            <span className={styles.vencGrupoDot} style={{background:'var(--ink-subtle)'}}/>
            Sin fecha de acceso asignada
            <span className={styles.vencGrupoCount}>{sin_acceso.length}</span>
          </div>
          <div className={styles.vencCardsGrid}>
            {sin_acceso.map(a => (
              <div key={a.id} className={styles.vencCard} style={{borderLeft:'3px solid var(--line)'}}>
                <div className={styles.vencCardHead}>
                  <div className={styles.vencAvatar} style={{background:'var(--surface-off)',color:'var(--ink-muted)'}}>
                    {a.username[0]!.toUpperCase()}
                  </div>
                  <div className={styles.vencInfo}>
                    <span className={styles.vencNombre}>{a.username}</span>
                    <span className={styles.vencFecha}>Acceso indefinido</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ── AsignaturasDetalle ─────────────────────────────────────────────────────
function AsignaturasDetalle({ stats, studentProfiles, onAlumnoClick }: {
  stats:           Stats
  studentProfiles: StudentProfile[]
  onAlumnoClick:   (a: AlumnoEnriquecido) => void
}) {
  const [subSel,  setSubSel]  = useState<string | null>(stats.bySubject?.[0]?.id ?? null)
  const [sortBy,  setSortBy]  = useState<'nota' | 'sesiones'>('nota')
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc')

  const spMap: Record<string, StudentProfile> = {}
  for (const sp of studentProfiles) spMap[sp.id] = sp

  const sub     = stats.bySubject?.find(s => s.id === subSel)
  const alumnos = useMemo<AlumnoEnriquecido[]>(() => {
    if (!sub) return []
    return [...sub.alumnosConNota].map(a => ({
      ...a,
      subjectName:   sub.name,
      subjectColor:  sub.color ?? '#6B7280',
      enRiesgo:      sub.alumnosEnRiesgo.some(r => r.id === a.id),
      diasInactivo:  sub.alumnosEnRiesgo.find(r => r.id === a.id)?.diasInactivo ?? null,
      diasRestantes: sub.alumnosPorExpirar.find(r => r.id === a.id)?.diasRestantes ?? null,
      extended:      spMap[a.id]?.extended ?? null,
      access_until:  spMap[a.id]?.access_until ?? null,
      created_at:    spMap[a.id]?.created_at ?? null,
    })).sort((a, b) => {
      const va = (a as any)[sortBy] ?? -1, vb = (b as any)[sortBy] ?? -1
      return sortDir === 'desc' ? vb - va : va - vb
    })
  }, [sub, sortBy, sortDir, studentProfiles])

  const handleSort = (col: 'nota' | 'sesiones') => {
    if (sortBy === col) setSortDir(d => d === 'desc' ? 'asc' : 'desc')
    else { setSortBy(col); setSortDir('desc') }
  }

  if (!stats.bySubject?.length) return null

  // Ranking comparativo
  const sorted       = [...stats.bySubject].sort((a,b) => (b.notaMedia??-1) - (a.notaMedia??-1))
  const maxNota      = Math.max(...stats.bySubject.map(s => s.notaMedia ?? 0), 1)
  const maxSesiones  = Math.max(...stats.bySubject.map(s => s.sesiones30d), 1)

  return (
    <div className={styles.asigDetalle}>

      {/* Comparativa ranking — solo si hay más de 1 asignatura */}
      {stats.bySubject.length > 1 && (
        <div className={styles.asigComparativa}>
          <div className={styles.asigComparativaTitulo}>
            <BarChart2 size={14}/> Comparativa entre asignaturas
          </div>
          <div className={styles.asigComparativaGrid}>
            {sorted.map((s, i) => (
              <div key={s.id} className={styles.asigComparativaRow}
                onClick={() => setSubSel(s.id)}
                style={{cursor:'pointer'}}>
                <div className={styles.asigComparativaRank}
                  style={{color: i===0?'#D97706':i===1?'#94A3B8':'#CD7C54'}}>
                  #{i+1}
                </div>
                <div className={styles.asigComparativaNombre}>
                  <div className={styles.alumnoDot} style={{background:s.color??'#6B7280'}}/>
                  <span>{s.name}</span>
                </div>
                <div className={styles.asigComparativaBarWrap}>
                  <div className={styles.asigComparativaBarLabel}>
                    <span style={{color: scoreColor(s.notaMedia), fontWeight:800}}>
                      {s.notaMedia!==null?`${s.notaMedia}%`:'—'}
                    </span>
                  </div>
                  <div className={styles.asigComparativaBar}>
                    <div className={styles.asigComparativaBarFill} style={{
                      width: `${s.notaMedia!==null ? (s.notaMedia/maxNota)*100 : 0}%`,
                      background: `linear-gradient(90deg, ${s.color??'#6B7280'}, ${s.color??'#6B7280'}88)`,
                      boxShadow: `0 0 8px ${s.color??'#6B7280'}44`,
                    }}/>
                  </div>
                </div>
                <div className={styles.asigComparativaMeta}>
                  <span>{s.totalAlumnos} alumnos</span>
                  <span>{s.sesiones30d} sesiones</span>
                  {s.enRiesgo > 0 && <span style={{color:'#DC2626'}}>⚠ {s.enRiesgo}</span>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className={styles.asigCards}>
        {stats.bySubject.map(s => (
          <button key={s.id} className={[styles.asigDetailCard, subSel===s.id?styles.asigDetailCardActive:''].join(' ')} style={{ ['--sc' as string]: s.color }} onClick={() => setSubSel(s.id)}>
            <div className={styles.asigDetailBar} />
            <div className={styles.asigDetailContent}>
              <span className={styles.asigDetailName}>{s.name}</span>
              <div className={styles.asigDetailKpis}>
                <div className={styles.asigDetailKpi}><span className={styles.asigDetailKpiVal}>{s.totalAlumnos}</span><span className={styles.asigDetailKpiLabel}>Alumnos</span></div>
                <div className={styles.asigDetailKpi}><span className={styles.asigDetailKpiVal} style={{ color: '#059669' }}>{s.alumnosActivos}</span><span className={styles.asigDetailKpiLabel}>Activos</span></div>
                <div className={styles.asigDetailKpi}><span className={styles.asigDetailKpiVal} style={{ color: scoreColor(s.notaMedia) }}>{s.notaMedia!==null?`${s.notaMedia}%`:'—'}</span><span className={styles.asigDetailKpiLabel}>Nota media</span></div>
                <div className={styles.asigDetailKpi}><span className={styles.asigDetailKpiVal}>{s.sesiones30d}</span><span className={styles.asigDetailKpiLabel}>Sesiones 30d</span></div>
              </div>
            </div>
          </button>
        ))}
      </div>
      {sub && (
        <div className={styles.asigAlumnos}>
          <div className={styles.asigAlumnosHead}>
            <h3 className={styles.asigAlumnosTitle} style={{ color: sub.color }}><span className={styles.asigAlumnosDot} style={{ background: sub.color }} />{sub.name}</h3>
            <div className={styles.asigAlumnosStats}>
              {sub.enRiesgo > 0 && <span className={styles.asigBadgeRed}>⚠ {sub.enRiesgo} en riesgo</span>}
              {sub.porExpirar > 0 && <span className={styles.asigBadgeAmber}>🔒 {sub.porExpirar} expiran pronto</span>}
            </div>
          </div>
          {alumnos.length === 0 ? <p className={styles.empty}>Sin alumnos en esta asignatura</p> : (
            <div className={styles.alumnosTable}>
              <div className={styles.alumnosTableHead}>
                <span>Alumno</span>
                <button className={styles.sortBtn} onClick={() => handleSort('nota')}>Nota <ArrowUpDown size={10} style={{ opacity: sortBy==='nota'?1:0.4 }} /></button>
                <button className={styles.sortBtn} onClick={() => handleSort('sesiones')}>Sesiones <ArrowUpDown size={10} style={{ opacity: sortBy==='sesiones'?1:0.4 }} /></button>
                <span>Estado</span><span />
              </div>
              {alumnos.map(a => {
                const mascota = MASCOTAS[String(a.extended?.mascota ?? '')]
                const nombre  = String(a.extended?.full_name ?? '') || a.username
                const color   = scoreColor(a.nota)
                return (
                  <div key={a.id} className={styles.alumnoRow} style={{ gridTemplateColumns: '1.5fr 100px 100px 120px 32px' }} onClick={() => onAlumnoClick(a)}>
                    <div className={styles.alumnoNameCell}>
                      <div className={styles.alumnoAvatarSm} style={{ background: color+'22', color }}>{mascota?mascota.emoji:nombre[0]!.toUpperCase()}</div>
                      <div>
                        <div style={{ fontWeight:700, fontSize:'0.82rem', color:'var(--ink)' }}>{nombre}</div>
                        {a.extended?.full_name && <div style={{ fontSize:'0.68rem', color:'var(--ink-muted)' }}>@{a.username}</div>}
                      </div>
                    </div>
                    <span style={{ color, fontWeight:700, fontSize:'0.88rem' }}>{a.nota!==null?`${a.nota}%`:'—'}</span>
                    <span style={{ fontSize:'0.82rem', color:'var(--ink-muted)' }}>{a.sesiones}</span>
                    <span className={a.enRiesgo?styles.estadoRiesgo:styles.estadoOk}>{a.enRiesgo?`${a.diasInactivo??'?'}d inactivo`:'Activo'}</span>
                    <ArrowRight size={13} className={styles.alumnoArrow} />
                  </div>
                )
              })}
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// ── AsignaturasCard ────────────────────────────────────────────────────────
function AsignaturasCard({ stats }: { stats: Stats }) {
  const subs = stats.bySubject ?? []
  if (subs.length === 0) return <div className={styles.examEmpty}><BookOpen size={22} strokeWidth={1.4} /><p>Sin asignaturas configuradas</p></div>
  return (
    <div className={styles.asigList}>
      {subs.map(sub => (
        <div key={sub.id} className={styles.asigRow}>
          <div className={styles.asigDot} style={{ background: sub.color }} />
          <div className={styles.asigInfo}>
            <span className={styles.asigNombre}>{sub.name}</span>
            <span className={styles.asigMeta}>{sub.totalAlumnos} alumnos · {sub.alumnosActivos} activos</span>
          </div>
          {sub.notaMedia !== null && <span className={styles.asigNota} style={{ color: scoreColor(sub.notaMedia) }}>{sub.notaMedia}%</span>}
        </div>
      ))}
    </div>
  )
}

// ── PagosSection — selector de mes + cards por alumno ────────────────────────
const STATUS_META_PAGOS: Record<string, {label:string; color:string; bg:string; icon:React.ElementType}> = {
  paid:    { label:'Pagado',    color:'#059669', bg:'rgba(5,150,105,0.08)',  icon:CheckCircle  },
  pending: { label:'Pendiente', color:'#D97706', bg:'rgba(217,119,6,0.08)',  icon:Clock        },
  overdue: { label:'Vencido',   color:'#DC2626', bg:'rgba(220,38,38,0.08)',  icon:AlertTriangle},
}

const MESES = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre']

function PagosSection({ alumnos, spMap, fmtEur }: {
  alumnos: ProfileSimple[]
  spMap:   Record<string, { monthly_price: number | null; payment_status: string; exam_date: string | null; full_name: string | null; city: string | null }>
  fmtEur:  (n: number) => string
}) {
  const now        = new Date()
  const [mes, setMes]               = useState(now.getMonth())
  const [ano, setAno]               = useState(now.getFullYear())
  const [localStatus, setLocalStatus] = useState<Record<string, string>>({})
  const [confirmado,  setConfirmado]  = useState<Record<string, string>>({})
  const [guardando,   setGuardando]   = useState<Record<string, boolean>>({})

  const alumnosConPrecio = alumnos.filter(a => spMap[a.id]?.monthly_price)

  const getStatus = (id: string) => localStatus[id] ?? spMap[id]?.payment_status ?? 'pending'

  // KPIs reactivos al estado local
  const kpiPagados    = alumnosConPrecio.filter(a => getStatus(a.id) === 'paid')
  const kpiPendientes = alumnosConPrecio.filter(a => getStatus(a.id) === 'pending')
  const kpiVencidos   = alumnosConPrecio.filter(a => getStatus(a.id) === 'overdue')
  const mrrCobrado    = kpiPagados.reduce((s, a) => s + (spMap[a.id]?.monthly_price ?? 0), 0)
  const mrrPendiente  = kpiPendientes.reduce((s, a) => s + (spMap[a.id]?.monthly_price ?? 0), 0)
  const mrrVencido    = kpiVencidos.reduce((s, a) => s + (spMap[a.id]?.monthly_price ?? 0), 0)

  const handleChange = async (alumnoId: string, newStatus: string) => {
    setGuardando(prev => ({ ...prev, [alumnoId]: true }))
    try {
      const { supabase: sb } = await import('../../../lib/supabase')
      const { error } = await sb.from('student_profiles').update({ payment_status: newStatus }).eq('id', alumnoId)
      if (!error) {
        setLocalStatus(prev => ({ ...prev, [alumnoId]: newStatus }))
        setConfirmado(prev => ({ ...prev, [alumnoId]: newStatus }))
        setTimeout(() => setConfirmado(prev => { const n = {...prev}; delete n[alumnoId]; return n }), 2200)
      }
    } finally {
      setGuardando(prev => ({ ...prev, [alumnoId]: false }))
    }
  }

  const prevMes = () => { if (mes === 0) { setMes(11); setAno(a => a - 1) } else setMes(m => m - 1) }
  const nextMes = () => { if (mes === 11) { setMes(0); setAno(a => a + 1) } else setMes(m => m + 1) }
  const isCurrentMonth = mes === now.getMonth() && ano === now.getFullYear()
  const isFuture = ano > now.getFullYear() || (ano === now.getFullYear() && mes > now.getMonth())

  return (
    <div className={styles.finanzasSection}>
      {/* Header con selector de mes */}
      <div className={styles.pagosSectionHeader}>
        <div className={styles.pagosSectionTitle}>
          <Euro size={14}/> Cobros
        </div>
        <div className={styles.pagosMesSelector}>
          <button className={styles.pagosMesBtn} onClick={prevMes}>‹</button>
          <span className={styles.pagosMesLabel}>
            {MESES[mes]} {ano}
            {isCurrentMonth && <span className={styles.pagosMesActual}>Actual</span>}
          </span>
          <button className={styles.pagosMesBtn} onClick={nextMes} disabled={isFuture}>›</button>
        </div>
      </div>

      {/* KPIs reactivos */}
      <div className={styles.pagosKpisRow}>
        <div className={[styles.pagosKpiCard, styles.pagosCardPaid].join(' ')}>
          <div className={styles.pagosKpiTop}>
            <span className={styles.pagosKpiNum} style={{color:'#059669'}}>{kpiPagados.length}</span>
            <span className={styles.pagosKpiImporte}>{fmtEur(mrrCobrado)}</span>
          </div>
          <span className={styles.pagosKpiNombre}>Pagados</span>
          <div className={styles.pagosKpiBar}>
            <div className={styles.pagosKpiBarFill} style={{width:`${alumnosConPrecio.length ? (kpiPagados.length/alumnosConPrecio.length)*100 : 0}%`, background:'#059669'}}/>
          </div>
        </div>
        <div className={[styles.pagosKpiCard, styles.pagosCardPending].join(' ')}>
          <div className={styles.pagosKpiTop}>
            <span className={styles.pagosKpiNum} style={{color:'#D97706'}}>{kpiPendientes.length}</span>
            <span className={styles.pagosKpiImporte}>{fmtEur(mrrPendiente)}</span>
          </div>
          <span className={styles.pagosKpiNombre}>Pendientes</span>
          <div className={styles.pagosKpiBar}>
            <div className={styles.pagosKpiBarFill} style={{width:`${alumnosConPrecio.length ? (kpiPendientes.length/alumnosConPrecio.length)*100 : 0}%`, background:'#D97706'}}/>
          </div>
        </div>
        <div className={[styles.pagosKpiCard, styles.pagosCardOverdue].join(' ')}>
          <div className={styles.pagosKpiTop}>
            <span className={styles.pagosKpiNum} style={{color:'#DC2626'}}>{kpiVencidos.length}</span>
            <span className={styles.pagosKpiImporte}>{fmtEur(mrrVencido)}</span>
          </div>
          <span className={styles.pagosKpiNombre}>Vencidos</span>
          <div className={styles.pagosKpiBar}>
            <div className={styles.pagosKpiBarFill} style={{width:`${alumnosConPrecio.length ? (kpiVencidos.length/alumnosConPrecio.length)*100 : 0}%`, background:'#DC2626'}}/>
          </div>
        </div>
      </div>

      {/* Cards por alumno */}
      <div className={styles.pagosAlumnosGrid}>
        {alumnosConPrecio.map((a) => {
          const sp      = spMap[a.id]!
          const status  = getStatus(a.id)
          const meta    = STATUS_META_PAGOS[status] ?? STATUS_META_PAGOS['pending']!
          const saving  = guardando[a.id] ?? false
          const conf    = confirmado[a.id]
          const confMeta= conf ? STATUS_META_PAGOS[conf] : null
          const StatusIcon = meta.icon

          return (
            <div key={a.id}
              className={[styles.pagosAlumnoCard,
                status==='paid'    ? styles.pagosCardPaid    :
                status==='overdue' ? styles.pagosCardOverdue :
                styles.pagosCardPending
              ].join(' ')}>
              {/* Cabecera */}
              <div className={styles.pagosAlumnoHead}>
                <div className={styles.pagosAlumnoAvatar} style={{background:meta.bg, color:meta.color}}>
                  {a.username[0]!.toUpperCase()}
                </div>
                <div className={styles.pagosAlumnoInfo}>
                  <span className={styles.pagosAlumnoNombre}>{a.username}</span>
                  <span className={styles.pagosAlumnoPrecio}>{fmtEur(sp.monthly_price!)}<span>/mes</span></span>
                </div>
                {/* Badge estado */}
                {conf && confMeta ? (
                  <span className={[styles.pagosEstadoBadge, styles.pagosBadgeConfirm].join(' ')}
                    style={{color:confMeta.color, background:confMeta.bg}}>
                    <Check size={10} strokeWidth={3}/>{confMeta.label}
                  </span>
                ) : (
                  <span className={styles.pagosEstadoBadge} style={{color:meta.color, background:meta.bg}}>
                    {saving
                      ? <RefreshCw size={10} className={styles.spinnerSmall}/>
                      : <StatusIcon size={10} strokeWidth={2.5}/>
                    }
                    {saving ? 'Guardando…' : meta.label}
                  </span>
                )}
              </div>
              {/* Botones de cambio */}
              <div className={styles.pagosAlumnoBtns}>
                {(['paid','pending','overdue'] as const).filter(s => s !== status).map(s => {
                  const m = STATUS_META_PAGOS[s]!
                  const BtnIcon = m.icon
                  return (
                    <button key={s} className={styles.pagosAlumnoBtn}
                      style={{'--btn-c': m.color} as React.CSSProperties}
                      disabled={saving}
                      onClick={() => handleChange(a.id, s)}>
                      <BtnIcon size={11} strokeWidth={2}/>{m.label}
                    </button>
                  )
                })}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ── FinanzasPanel ──────────────────────────────────────────────────────────
function FinanzasPanel({ stats, profiles }: { stats: Stats; profiles: ProfileSimple[] }) {
  const fin = stats.finanzas
  const [precioBase,  setPrecioBase]  = useState('')
  const [editando,    setEditando]    = useState(false)
  const [inputPrecio, setInputPrecio] = useState('')

  if (!fin) return null

  const now     = new Date()
  const alumnos = profiles.filter(p => p.role === 'alumno')
  const fmtEur  = (n: number) => new Intl.NumberFormat('es-ES', { style:'currency', currency:'EUR', maximumFractionDigits: 0 }).format(n)

  // MRR con precio base para alumnos sin precio individual
  const precioBaseNum  = precioBase ? parseFloat(precioBase) : 0
  const mrrConBase     = fin.mrrAcademia + (fin.alumnosSinPrecio * precioBaseNum)
  const arrEstimado    = mrrConBase * 12

  // MRR en riesgo — alumnos inactivos o con acceso a punto de expirar
  const mrrRiesgo = alumnos
    .filter(a => {
      const sp = fin.spMap[a.id]
      if (!sp?.monthly_price) return false
      const diasRestantes = a.access_until
        ? Math.ceil((new Date(a.access_until).getTime() - now.getTime()) / 86400000)
        : null
      return diasRestantes !== null && diasRestantes <= 30
    })
    .reduce((sum, a) => sum + (fin.spMap[a.id]?.monthly_price ?? 0), 0)

  // Vencimientos próximos (30 días)
  const vencen30 = alumnos
    .filter(a => a.access_until)
    .map(a => ({
      username:    a.username,
      accessUntil: a.access_until!,
      dias:        Math.ceil((new Date(a.access_until!).getTime() - now.getTime()) / 86400000),
      precio:      fin.spMap[a.id]?.monthly_price ?? null,
    }))
    .filter(a => a.dias > 0 && a.dias <= 30)
    .sort((a, b) => a.dias - b.dias)

  // Alumnos sin precio asignado
  const sinPrecio = alumnos
    .filter(a => !fin.spMap[a.id]?.monthly_price)
    .map(a => ({ username: a.username, accessUntil: a.access_until }))

  return (
    <div className={styles.finanzasWrap}>

      {/* KPIs financieros */}
      <div className={styles.finanzasKpis}>
        <div className={styles.finanzasKpi}>
          <div className={styles.finanzasKpiIcon} style={{background:'rgba(5,150,105,0.1)',color:'#059669'}}>
            <Euro size={18} strokeWidth={1.8}/>
          </div>
          <div className={styles.finanzasKpiVal}>{fmtEur(mrrConBase)}</div>
          <div className={styles.finanzasKpiLabel}>MRR Academia</div>
          <div className={styles.finanzasKpiSub}>{fin.totalAlumnosConPrecio} alumnos con precio</div>
        </div>
        <div className={styles.finanzasKpi}>
          <div className={styles.finanzasKpiIcon} style={{background:'rgba(37,99,235,0.1)',color:'#2563EB'}}>
            <TrendingUp size={18} strokeWidth={1.8}/>
          </div>
          <div className={styles.finanzasKpiVal}>{fmtEur(arrEstimado)}</div>
          <div className={styles.finanzasKpiLabel}>ARR estimado</div>
          <div className={styles.finanzasKpiSub}>MRR × 12 meses</div>
        </div>
        <div className={styles.finanzasKpi}>
          <div className={styles.finanzasKpiIcon} style={{background:'rgba(220,38,38,0.1)',color:'#DC2626'}}>
            <TrendingDown size={18} strokeWidth={1.8}/>
          </div>
          <div className={styles.finanzasKpiVal} style={{color:'#DC2626'}}>-{fmtEur(mrrRiesgo)}</div>
          <div className={styles.finanzasKpiLabel}>MRR en riesgo</div>
          <div className={styles.finanzasKpiSub}>Accesos que vencen en 30d</div>
        </div>
        <div className={styles.finanzasKpi} style={fin.alumnosSinPrecio > 0 ? {borderColor:'rgba(220,38,38,0.3)'} : {}}>
          <div className={styles.finanzasKpiIcon} style={{background:'rgba(220,38,38,0.1)',color:'#DC2626'}}>
            <AlertTriangle size={18} strokeWidth={1.8}/>
          </div>
          <div className={styles.finanzasKpiVal} style={fin.alumnosSinPrecio > 0 ? {color:'#DC2626'} : {}}>{fin.alumnosSinPrecio}</div>
          <div className={styles.finanzasKpiLabel}>Sin precio asignado</div>
          <div className={styles.finanzasKpiSub}>No cuentan en el MRR</div>
        </div>
      </div>

      <PagosSection alumnos={alumnos} spMap={fin.spMap} fmtEur={fmtEur} />

      {/* Precio base para alumnos sin precio individual */}
      <div className={styles.finanzasPrecioBase}>
        <div className={styles.finanzasPrecioBaseInfo}>
          <Euro size={13} style={{color:'var(--ink-muted)'}}/>
          <span>Precio base para alumnos sin precio individual</span>
          {precioBase && <span className={styles.finanzasPrecioBaseActivo}>{precioBase} €/mes aplicado</span>}
        </div>
        {editando ? (
          <div className={styles.finanzasPrecioBaseForm}>
            <input type="number" className={styles.finanzasPrecioInput}
              value={inputPrecio} onChange={e => setInputPrecio(e.target.value)}
              placeholder="ej: 89" min="0" autoFocus />
            <button className={styles.finanzasPrecioBtn} onClick={() => { setPrecioBase(inputPrecio); setEditando(false) }}>Aplicar</button>
            <button className={styles.finanzasPrecioBtnCancel} onClick={() => setEditando(false)}>Cancelar</button>
          </div>
        ) : (
          <button className={styles.finanzasPrecioEditBtn} onClick={() => { setEditando(true); setInputPrecio(precioBase) }}>
            {precioBase ? 'Cambiar' : '+ Añadir precio base'}
          </button>
        )}
      </div>

      {/* Próximos vencimientos */}
      {vencen30.length > 0 && (
        <div className={styles.finanzasSection}>
          <div className={styles.finanzasSectionTitle}><Clock size={14}/> Accesos que vencen en 30 días</div>
          <div className={styles.finanzasTable}>
            <div className={styles.finanzasTableHead}>
              <span>Alumno</span><span>Vence en</span><span>Fecha</span><span>Precio/mes</span>
            </div>
            {vencen30.map((a, i) => (
              <div key={i} className={styles.finanzasTableRow}>
                <span className={styles.finanzasUsername}>{a.username}</span>
                <span className={[styles.finanzasDias, a.dias <= 7 ? styles.finanzasDiasRed : a.dias <= 14 ? styles.finanzasDiasAmber : styles.finanzasDiasGreen].join(' ')}>{a.dias}d</span>
                <span className={styles.finanzasFecha}>{new Date(a.accessUntil).toLocaleDateString('es-ES',{day:'2-digit',month:'short'})}</span>
                <span className={styles.finanzasPrecio}>{a.precio ? fmtEur(a.precio) : <span style={{color:'var(--ink-subtle)'}}>Sin precio</span>}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Alumnos sin precio */}
      {sinPrecio.length > 0 && (
        <div className={styles.finanzasSection}>
          <div className={styles.finanzasSectionTitle} style={{color:'#DC2626'}}><AlertTriangle size={14}/> Sin precio asignado — no contabilizan en el MRR</div>
          <div className={styles.finanzasAlertList}>
            {sinPrecio.map((a, i) => (
              <div key={i} className={styles.finanzasAlertRow}>
                <span>{a.username}</span>
                <span style={{color:'var(--ink-subtle)',fontSize:'var(--fs-6)'}}>{a.accessUntil ? `Acceso hasta ${new Date(a.accessUntil).toLocaleDateString('es-ES',{day:'2-digit',month:'short',year:'numeric'})}` : 'Sin fecha de acceso'}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ── DirectorBentoNav ───────────────────────────────────────────────────────
function DirectorBentoNav({ tab, setTab, stats, nAlertas, studentProfiles, nMensajes, nRespuestas }: {
  tab: string; setTab: (t: string) => void; stats: Stats; nAlertas: number; studentProfiles: StudentProfile[]
  nMensajes: number; nRespuestas: number
}) {
  const preciosReales = studentProfiles.filter(p => p.extended?.monthly_price).map(p => parseFloat(String(p.extended!.monthly_price)))
  const mrr = preciosReales.length > 0 ? preciosReales.reduce((a, b) => a + b, 0) : null

  const cards = [
    { id:'overview',    label:'Actividad',    desc: stats.sesiones30d>0?`${stats.sesiones30d} sesiones este mes`:'Sin sesiones todavía',                                                      icon:TrendingUp,   color:'#0891B2', big:true,  isAsig:false, badge:null as number|null },
    { id:'alumnos',     label:'Alumnos',      desc: stats.totalAlumnos>0?`${stats.totalAlumnos} matriculados · ${stats.totalActivos} activos`:'Sin alumnos aún',                              icon:Users,        color:'#2563EB', big:false, isAsig:false, badge:null as number|null },
    { id:'alertas',     label:'Alertas',      desc: nAlertas>0?`${nAlertas} acción${nAlertas!==1?'es':''} pendiente${nAlertas!==1?'s':''}`:'Todo en orden',                                   icon:AlertTriangle,color:nAlertas>0?'#DC2626':'#059669', big:false, isAsig:false, badge:nAlertas>0?nAlertas:null as number|null },
    { id:'profesores',  label:'Profesores',   desc: stats.totalProfesores>0?`${stats.totalProfesores} profesor${stats.totalProfesores!==1?'es':''}`:'Sin profesores aún',                    icon:GraduationCap,color:'#7C3AED', big:false, isAsig:false, badge:null as number|null },
    { id:'finanzas',    label:'Finanzas',     desc: stats.finanzas ? `${new Intl.NumberFormat('es-ES',{style:'currency',currency:'EUR',maximumFractionDigits:0}).format(stats.finanzas.mrrAcademia)}/mes` : 'Ver ingresos', descExtra: null, icon:Euro, color:'#059669', big:false, isAsig:false, badge:null as number|null },
    { id:'comunicacion', label:'Comunicación', desc: nMensajes>0?`${nMensajes} mensaje${nMensajes!==1?'s':''} enviado${nMensajes!==1?'s':''}`:'Mensajes directos', descExtra: null, icon:MessageSquare, color:'#0891B2', big:false, isAsig:false, badge: nRespuestas > 0 ? nRespuestas : null as number|null },
    { id:'vencimientos', label:'Vencimientos', desc: (stats.totalPorExpirar>0?`${stats.totalPorExpirar} expiran pronto`:'Gestión de accesos'), descExtra: null, icon:Calendar, color:'#D97706', big:false, isAsig:false, badge: stats.totalPorExpirar>0?stats.totalPorExpirar:null as number|null },
    { id:'retencion',   label:'Retención',    desc: 'Permanencia y cohortes', descExtra: null, icon:TrendingUp, color:'#7C3AED', big:false, isAsig:false, badge:null as number|null },
    { id:'asignaturas', label:'Asignaturas',  desc: `${stats.bySubject?.length??0} asignatura${(stats.bySubject?.length??0)!==1?'s':''} activa${(stats.bySubject?.length??0)!==1?'s':''}`, icon:BookOpen,     color:'#D97706', big:false, isAsig:true,  badge:null as number|null },

  ]

  return (
    <div className={styles.bentoGrid}>
      {cards.map(card => {
        const Icon = card.icon, active = tab===card.id
        return (
          <button key={card.id}
            className={[styles.bentoCard, card.big?styles.bentoBig:'', active&&!card.isAsig?styles.bentoActive:'', card.isAsig?styles.bentoExam:''].join(' ')}
            style={{ ['--bento-color' as string]: card.color }}
            onClick={() => setTab(card.isAsig?'asignaturas':card.id)}>
            {card.big && !card.isAsig && <AnimatedGridPattern numSquares={18} maxOpacity={active?0.12:0.06} duration={4} color={card.color} lineColor={card.color+'20'} />}
            {!card.isAsig && <Ripple mainCircleSize={card.big?60:40} mainCircleOpacity={active?0.25:0.12} numCircles={card.big?5:3} color={card.color} duration={card.big?3:3.5} />}
            {card.isAsig ? (
              <div className={styles.bentoContent}>
                <div className={styles.bentoExamHeader}>
                  <div className={styles.bentoIconWrap} style={{ background:card.color+'18', color:card.color }}><Icon size={16} strokeWidth={1.8} /></div>
                  <span className={styles.bentoLabel}>{card.label}</span>
                </div>
                <AsignaturasCard stats={stats} />
              </div>
            ) : (
              <div className={styles.bentoContent}>
                <div className={styles.bentoIconWrap} style={{ background:card.color+'18', color:card.color }}><Icon size={card.big?20:16} strokeWidth={1.8} /></div>
                <div className={styles.bentoText}><span className={styles.bentoLabel}>{card.label}</span><span className={styles.bentoDesc}>{card.desc}</span></div>
                {card.badge!=null&&card.badge>0&&<span className={styles.bentoBadge} style={{ background:card.color }}>{card.badge}</span>}
              </div>
            )}
          </button>
        )
      })}
    </div>
  )
}

// ── Panel principal ────────────────────────────────────────────────────────
export default function DirectorPanel({ currentUser }: { currentUser: CurrentUser | null }) {
  const { stats, allProfiles, loading, error } = useDirector(currentUser)
  const { sent: dmSent, sendMessage: dmSend, deleteSentMessage: dmDelete } = useProfesorMessages(
    currentUser?.id, currentUser?.academy_id, currentUser?.subject_id
  )
  const { studentProfiles, staffProfiles, loading: loadingProfiles, updateStudentProfile } = useAcademyProfiles(currentUser?.academy_id)

  const [tab,           setTab]           = useState('overview')
  const [alumnoDetalle, setAlumnoDetalle] = useState<AlumnoEnriquecido | null>(null)
  const [profDetalle,   setProfDetalle]   = useState<StudentProfile | null>(null)

  const bentoRef   = useRef<HTMLDivElement>(null)
  const contentRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!tab || !contentRef.current) return
    setTimeout(() => contentRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80)
  }, [tab])

  const handleSaveAlumno = useCallback(async (userId: string, fields: AlumnoDetalleForm) => {
    const spFields = {
      full_name:     fields.full_name     || null,
      phone:         fields.phone         || null,
      email_contact: fields.email_contact || null,
      city:          fields.city          || null,
      exam_date:     fields.exam_date     || null,
      monthly_price: fields.monthly_price ? parseFloat(fields.monthly_price) : null,
    }
    await updateStudentProfile(userId, spFields)
    if (fields.access_until) {
      await supabase.from('profiles').update({ access_until: new Date(fields.access_until + 'T23:59:59').toISOString() }).eq('id', userId)
    }
  }, [updateStudentProfile])

  if (loading || loadingProfiles) return <div className={styles.state}><RefreshCw size={22} className={styles.spinner} /><p>Cargando datos…</p></div>
  if (error)  return <ErrorState message={error ?? 'Error cargando los datos del panel.'} onRetry={() => window.location.reload()} />
  if (!stats) return null

  const typedStats = stats as unknown as Stats

  const spMap: Record<string, StudentProfile> = {}
  for (const sp of studentProfiles as StudentProfile[]) spMap[sp.id] = sp

  const enrichAlumno = (a: any): AlumnoEnriquecido => {
    const sp = spMap[a.id]
    return {
      ...a,
      extended:      sp?.extended      ?? null,
      access_until:  sp?.access_until  ?? null,
      created_at:    sp?.created_at    ?? null,
      subjectName:   a.subjectName     ?? '',
      subjectColor:  a.subjectColor    ?? '#6B7280',
      enRiesgo:      a.enRiesgo        ?? false,
      diasInactivo:  a.diasInactivo    ?? null,
      diasRestantes: a.diasRestantes   ?? null,
    }
  }

  if (alumnoDetalle) {
    const statsAlumno = typedStats.bySubject.flatMap(sub => sub.alumnosConNota.map(a => ({
      ...a,
      enRiesgo:    sub.alumnosEnRiesgo.some(r => r.id === a.id),
      diasInactivo: sub.alumnosEnRiesgo.find(r => r.id === a.id)?.diasInactivo ?? null,
      fallos:      0,
    }))).find(a => a.id === alumnoDetalle.id)
    return <AlumnoDetallePanel alumno={alumnoDetalle} statsAlumno={statsAlumno} onBack={() => setAlumnoDetalle(null)} onSave={handleSaveAlumno} />
  }

  if (profDetalle) return <ProfesorDetallePanel profesor={profDetalle} onBack={() => setProfDetalle(null)} />

  const nAlertas              = typedStats.totalEnRiesgo + typedStats.totalPorExpirar
  const academyProfilesForTable = { studentProfiles: studentProfiles as StudentProfile[], staffProfiles: staffProfiles as StudentProfile[] }

  return (
    <div className={styles.page}>
      <OnboardingChecklist currentUser={currentUser} stats={typedStats} />

      <div className={styles.pageHeader}>
        <div><h1 className={styles.pageTitle}>Panel de Dirección</h1><p className={styles.pageSubtitle}>{currentUser?.academyName ?? 'Tu academia'}</p></div>
        <button className={styles.btnExport} onClick={() => exportarInforme(typedStats, currentUser?.academyName, studentProfiles as StudentProfile[])}>
          <FileText size={14} /> Exportar PDF
        </button>
      </div>

      <NarrativaCard stats={typedStats} />

      <div className={styles.kpisRow}>
        <KpiCard icon={Users}         label="Alumnos"        value={typedStats.totalAlumnos}    color="#0891B2" />
        <KpiCard icon={GraduationCap} label="Profesores"     value={typedStats.totalProfesores} color="#7C3AED" />
        <KpiCard icon={Zap}           label="Activos 7d"     value={typedStats.totalActivos}    color="#059669" sub={`${typedStats.totalAlumnos>0?Math.round(typedStats.totalActivos/typedStats.totalAlumnos*100):0}% del total`} />
        <KpiCard icon={BarChart2}     label="Nota media 30d" value={typedStats.notaGlobal!==null?`${typedStats.notaGlobal}%`:'—'} color={scoreColor(typedStats.notaGlobal)} />
        <KpiCard icon={AlertTriangle} label="En riesgo"      value={typedStats.totalEnRiesgo}   color="#DC2626" alert={typedStats.totalEnRiesgo>0} />
        <KpiCard icon={Shield}        label="Expiran pronto" value={typedStats.totalPorExpirar} color="#B45309" alert={typedStats.totalPorExpirar>0} />
      </div>

      <div ref={bentoRef}>
        <DirectorBentoNav tab={tab} setTab={setTab} stats={typedStats} nAlertas={nAlertas} studentProfiles={studentProfiles as StudentProfile[]} nMensajes={dmSent.length} nRespuestas={dmSent.filter((m: {reply_body:string|null}) => m.reply_body).length} />
      </div>

      <div ref={contentRef} className={styles.contentArea}>
        {tab==='asignaturas' && <AsignaturasDetalle stats={typedStats} studentProfiles={studentProfiles as StudentProfile[]} onAlumnoClick={a => setAlumnoDetalle(enrichAlumno(a))} />}
        {tab==='overview' && (
          <div className={styles.section}>
            <div className={styles.chartCard}>
              <div className={styles.chartCardHead}><h3 className={styles.chartCardTitle}>Sesiones por semana</h3><span className={styles.chartCardSub}>Últimas 8 semanas</span></div>
              <ActivityChart semanas={typedStats.semanas} />
              {typedStats.sesiones30d===0 && <p className={styles.empty}>Sin sesiones todavía</p>}
            </div>
            <div className={styles.subList}>
              {typedStats.bySubject.map(sub => (
                <div key={sub.id} className={styles.subCard} style={{ ['--sc' as string]: sub.color }}>
                  <div className={styles.subCardBar} />
                  <div className={styles.subCardInfo}>
                    <span className={styles.subCardName}>{sub.name}</span>
                    <div className={styles.subCardMeta}>
                      <span><Users size={11} /> {sub.totalAlumnos} alumnos</span>
                      <span><Zap size={11} /> {sub.alumnosActivos} activos</span>
                      <span><BarChart2 size={11} /> {sub.sesiones30d} sesiones 30d</span>
                    </div>
                  </div>
                  {sub.notaMedia!==null && <span className={styles.subCardNota} style={{ color: scoreColor(sub.notaMedia) }}>{sub.notaMedia}%</span>}
                </div>
              ))}
            </div>
          </div>
        )}
        {tab==='alumnos'     && <AlumnosTable stats={typedStats} academyProfiles={academyProfilesForTable} onAlumnoClick={a => setAlumnoDetalle(enrichAlumno(a))} />}
        {tab==='profesores'  && <ProfesoresTable staffProfiles={staffProfiles as StudentProfile[]} stats={typedStats} onProfesorClick={setProfDetalle} />}
        {tab==='alertas'     && <AlertasPanel stats={typedStats} onAlumnoClick={a => setAlumnoDetalle(enrichAlumno(a))} />}
        {tab==='retencion'   && <RetencionPanel profiles={(allProfiles ?? []) as ProfileSimple[]} />}
        {tab==='vencimientos' && <VencimientosPanel
          profiles={(allProfiles ?? []) as ProfileSimple[]}
          onRenovar={(id, username) => {
            const sp = studentProfiles.find((p: any) => p.id === id)
            if (sp) setAlumnoDetalle(enrichAlumno(sp as any))
          }}
        />}
        {tab==='comunicacion' && <ComunicacionPanel currentUser={currentUser} profiles={(allProfiles ?? []) as ProfileSimple[]} mensajes={dmSent} onDelete={dmDelete} />}
        {tab==='finanzas'    && <FinanzasPanel stats={typedStats} profiles={(allProfiles ?? []) as ProfileSimple[]} />}
        {tab && <button className={styles.scrollBackBtn} onClick={() => bentoRef.current?.scrollIntoView({ behavior:'smooth', block:'start' })} aria-label="Volver arriba"><ChevronUp size={18} strokeWidth={2.5} /></button>}
      </div>
    </div>
  )
}
