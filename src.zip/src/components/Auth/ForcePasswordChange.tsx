import { useState } from 'react'
import { supabase } from '../../lib/supabase'
import { Lock, Eye, EyeOff, ArrowRight, AlertCircle, Check } from 'lucide-react'
import type { CurrentUser } from '../../types'
import styles from '../Auth/Auth.module.css'

interface ForcePasswordChangeProps {
  currentUser: CurrentUser | { username: string }
  onDone:      (password: string) => Promise<boolean | void>
  isRecovery?: boolean
}

export default function ForcePasswordChange({
  currentUser,
  onDone,
  isRecovery = false,
}: ForcePasswordChangeProps) {
  const [password,  setPassword]  = useState('')
  const [password2, setPassword2] = useState('')
  const [showPw,    setShowPw]    = useState(false)
  const [showPw2,   setShowPw2]   = useState(false)
  const [loading,   setLoading]   = useState(false)
  const [error,     setError]     = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    if (password.length < 6) {
      setError('La contraseña debe tener al menos 6 caracteres')
      return
    }
    if (password !== password2) {
      setError('Las contraseñas no coinciden')
      return
    }

    setLoading(true)

    if (isRecovery) {
      // Try to change password directly here so we can catch the specific error
      const { error: authErr } = await supabase.auth.updateUser({ password })
      if (authErr) {
        if (authErr.message.toLowerCase().includes('same') ||
            authErr.message.toLowerCase().includes('different') ||
            authErr.message.toLowerCase().includes('nueva') ||
            authErr.message.toLowerCase().includes('password')) {
          setError('La nueva contraseña debe ser diferente a la anterior.')
        } else {
          setError('El enlace ha expirado o ya fue usado. Solicita uno nuevo desde "Olvidé mi contraseña".')
        }
        setLoading(false)
        return
      }
      await onDone(password)
      return
    }

    // Modo primer login: cambiar contraseña directamente y llamar onDone
    const { error: authErr } = await supabase.auth.updateUser({ password })
    if (authErr) {
      setError(authErr.message)
      setLoading(false)
      return
    }
    await onDone(password)
    setLoading(false)
  }

  return (
    <div className={styles.page}>
      <div className={styles.card}>
        <div className={styles.cardHeader}>
          <div style={{
            width: 48, height: 48, borderRadius: '50%',
            background: 'var(--surface-raised)', display: 'flex',
            alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 1rem',
          }}>
            <Lock size={22} strokeWidth={1.8} style={{ color: 'var(--ink)' }} />
          </div>
          <h1 className={styles.title}>
            {isRecovery ? 'Nueva contraseña' : 'Cambia tu contraseña'}
          </h1>
          <p className={styles.subtitle}>
            {isRecovery
              ? 'Elige una contraseña nueva para tu cuenta.'
              : <>Hola <strong>{currentUser.username}</strong>, es tu primer acceso. Elige una contraseña nueva para continuar.</>
            }
          </p>
        </div>

        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label className={styles.label}>Nueva contraseña</label>
            <div className={styles.inputWrap}>
              <Lock size={16} className={styles.inputIcon} />
              <input
                className={styles.input}
                type={showPw ? 'text' : 'password'}
                placeholder="Mínimo 6 caracteres"
                value={password}
                onChange={e => { setPassword(e.target.value); setError('') }}
                autoFocus
                autoComplete="new-password"
              />
              <button type="button" className={styles.eyeBtn}
                onClick={() => setShowPw(v => !v)} tabIndex={-1}>
                {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
            </div>
          </div>

          <div className={styles.field}>
            <label className={styles.label}>Repite la contraseña</label>
            <div className={styles.inputWrap}>
              <Lock size={16} className={styles.inputIcon} />
              <input
                className={styles.input}
                type={showPw2 ? 'text' : 'password'}
                placeholder="Repite la contraseña"
                value={password2}
                onChange={e => { setPassword2(e.target.value); setError('') }}
                autoComplete="new-password"
              />
              <button type="button" className={styles.eyeBtn}
                onClick={() => setShowPw2(v => !v)} tabIndex={-1}>
                {showPw2 ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
            </div>
          </div>

          {password && password2 && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: '0.4rem',
              fontSize: '0.82rem', fontWeight: 500,
              color: password === password2 ? '#059669' : '#DC2626',
              marginTop: '-0.25rem',
            }}>
              {password === password2
                ? <><Check size={13} /> Las contraseñas coinciden</>
                : <><AlertCircle size={13} /> No coinciden</>
              }
            </div>
          )}

          {error && (
            <div className={styles.error}>
              <AlertCircle size={15} />
              <span>{error}</span>
            </div>
          )}

          <button
            className={[styles.submit, loading ? styles.submitLoading : ''].join(' ')}
            type="submit"
            disabled={loading || !password || !password2}
          >
            {loading
              ? <span className={styles.spinner} />
              : <><Check size={16} /> Guardar y entrar <ArrowRight size={16} /></>
            }
          </button>
        </form>
      </div>

      <p className={styles.note}>
        {isRecovery
          ? 'Tras guardar entrarás directamente a tu cuenta.'
          : 'Esta pantalla solo aparece una vez. Después entrarás directamente.'
        }
      </p>
    </div>
  )
}
