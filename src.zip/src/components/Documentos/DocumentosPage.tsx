import { useState, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft, FileText, Video, FileCheck, Loader2, Download, ExternalLink, ChevronUp } from 'lucide-react'
import { supabase } from '../../lib/supabase'
import GlassFolder, { type FolderColor } from './GlassFolder'
import { useDocuments, type AcademyDocument } from '../../hooks/useDocuments'
import type { CurrentUser } from '../../types'
import styles from './DocumentosPage.module.css'

interface Props {
  currentUser: CurrentUser | null
}

type Category = 'contrato' | 'material' | 'video'

interface FolderConfig {
  id:       Category
  label:    string
  sublabel: string
  color:    FolderColor
  icon:     React.ReactNode
  iconBg:   string
  emptyMsg: string
  fileIcon: (url: string) => string
}

const FOLDERS: FolderConfig[] = [
  {
    id:       'contrato',
    label:    'Contrato',
    sublabel: 'Documentos oficiales',
    color:    'purple',
    icon:     <FileCheck size={18} />,
    iconBg:   'linear-gradient(135deg, #6B46E0, #4F2FC0)',
    emptyMsg: 'Tu academia aún no ha subido ningún contrato.',
    fileIcon: () => '📋',
  },
  {
    id:       'material',
    label:    'Material de estudio',
    sublabel: 'PDFs y apuntes',
    color:    'dark',
    icon:     <FileText size={18} />,
    iconBg:   'linear-gradient(135deg, #2C2C2E, #1C1C1E)',
    emptyMsg: 'Tu profesor aún no ha subido material de estudio.',
    fileIcon: () => '📄',
  },
  {
    id:       'video',
    label:    'Vídeos',
    sublabel: 'Clases y recursos',
    color:    'blue',
    icon:     <Video size={18} />,
    iconBg:   'linear-gradient(135deg, #2563EB, #1D4ED8)',
    emptyMsg: 'Aún no hay vídeos compartidos.',
    fileIcon: (url) => url.includes('youtube') || url.includes('youtu.be') ? '▶️' : url.includes('vimeo') ? '🎬' : '🎥',
  },
]

function formatSize(bytes: number | null): string {
  if (!bytes) return ''
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

function fmtFecha(iso: string): string {
  return new Date(iso).toLocaleDateString('es-ES', {
    day: '2-digit', month: 'short', year: 'numeric'
  })
}

function FileItem({ doc }: { doc: AcademyDocument }) {
  const [downloading, setDownloading] = useState(false)
  const isVideo = doc.category === 'video'

  const handleClick = async () => {
    // Vídeos: abrir enlace externo directamente
    if (isVideo) {
      window.open(doc.url, '_blank', 'noopener,noreferrer')
      return
    }

    // Archivos: descargar via edge function (bucket privado)
    setDownloading(true)
    try {
      const { data: { session } } = await supabase.auth.getSession()
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/descargar-documento`,
        {
          method:  'POST',
          headers: {
            'Content-Type':  'application/json',
            'Authorization': `Bearer ${session?.access_token}`,
            'apikey':        import.meta.env.VITE_SUPABASE_ANON_KEY,
          },
          body: JSON.stringify({ document_id: doc.id }),
        }
      )
      if (!res.ok) throw new Error('Error al descargar')
      const blob = await res.blob()
      const url  = URL.createObjectURL(blob)
      const a    = document.createElement('a')
      a.href     = url
      a.download = doc.title
      a.click()
      URL.revokeObjectURL(url)
    } catch {
      alert('No se pudo descargar el archivo. Inténtalo de nuevo.')
    } finally {
      setDownloading(false)
    }
  }

  const Icon = isVideo ? Video : doc.category === 'contrato' ? FileCheck : FileText

  return (
    <button
      onClick={handleClick}
      disabled={downloading}
      className={styles.fileItem}
    >
      <span className={styles.fileItemIcon}><Icon size={16} /></span>
      <span className={styles.fileItemName}>{doc.title}</span>
      {doc.file_size && (
        <span className={styles.fileItemSize}>{formatSize(doc.file_size)}</span>
      )}
      {doc.uploader_name && (
        <span className={styles.fileItemUploader}>
          {doc.uploader_name}
          {doc.uploader_role === 'director' ? ' · Director' : doc.uploader_role === 'profesor' ? ' · Profesor' : ''}
        </span>
      )}
      <span className={styles.fileItemDate}>{fmtFecha(doc.created_at)}</span>
      <span className={styles.fileItemAction}>
        {downloading
          ? <Loader2 size={14} style={{ animation: 'spin 1s linear infinite' }} />
          : isVideo ? <ExternalLink size={14} /> : <Download size={14} />
        }
      </span>
    </button>
  )
}

export default function DocumentosPage({ currentUser }: Props) {
  const navigate = useNavigate()
  const { byCategory, loading, error } = useDocuments(currentUser)
  const [openFolder, setOpenFolder] = useState<Category | null>(null)
  const panelRef   = useRef<HTMLDivElement>(null)
  const foldersRef = useRef<HTMLDivElement>(null)

  const handleFolder = (id: Category) => {
    const isOpening = openFolder !== id
    setOpenFolder(prev => prev === id ? null : id)
    if (isOpening) {
      setTimeout(() => {
        panelRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
      }, 50)
    }
  }

  const scrollToTop = () => {
    foldersRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  if (loading) {
    return (
      <div className={styles.page}>
        <div className={styles.loading}>
          <Loader2 size={18} style={{ animation: 'spin 1s linear infinite' }} />
          Cargando documentos...
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className={styles.page}>
        <div className={styles.loading}>{error}</div>
      </div>
    )
  }

  const activeFolder = FOLDERS.find(f => f.id === openFolder)
  const activeDocs   = openFolder ? byCategory(openFolder) : []

  return (
    <div className={styles.page}>
      {/* Header */}
      <div className={styles.header}>
        <button className={styles.backBtn} onClick={() => navigate('/')}>
          <ArrowLeft size={16} />
          Inicio
        </button>
        <h1 className={styles.title}>Tus documentos</h1>
      </div>

      {/* Carpetas */}
      <div ref={foldersRef} className={styles.foldersRow}>
        {FOLDERS.map(folder => (
          <GlassFolder
            key={folder.id}
            label={folder.label}
            sublabel={folder.sublabel}
            count={byCategory(folder.id).length}
            color={folder.color}
            isOpen={openFolder === folder.id}
            onClick={() => handleFolder(folder.id)}
          />
        ))}
      </div>

      {/* Panel de archivos */}
      {activeFolder && (
        <div ref={panelRef} className={styles.filesPanel}>
          <div className={styles.filesPanelHeader}>
            <div
              className={styles.filesPanelIcon}
              style={{ background: activeFolder.iconBg, color: '#fff' }}
            >
              {activeFolder.icon}
            </div>
            <div>
              <p className={styles.filesPanelTitle}>{activeFolder.label}</p>
              <p className={styles.filesPanelCount}>{activeDocs.length} archivos</p>
            </div>
          </div>

          {activeDocs.length === 0 ? (
            <div className={styles.empty}>
              <span className={styles.emptyIcon}>📭</span>
              {activeFolder.emptyMsg}
            </div>
          ) : (
            <div className={styles.fileList}>
              {activeDocs.map(doc => (
                <FileItem key={doc.id} doc={doc} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Volver arriba */}
      {openFolder && (
        <button className={styles.scrollUpBtn} onClick={scrollToTop} aria-label="Volver a carpetas">
          <ChevronUp size={18} strokeWidth={2.5} />
        </button>
      )}
    </div>
  )
}
