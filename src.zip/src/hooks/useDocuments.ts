import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import type { CurrentUser } from '../types'

export interface AcademyDocument {
  id:              string
  category:        'contrato' | 'material' | 'video'
  title:           string
  url:             string
  file_size:       number | null
  created_at:      string
  alumno_id:       string | null
  uploaded_by:     string | null
  uploader_name:   string | null   // nombre del profesor/director que subió
  uploader_role:   string | null   // 'profesor' | 'director' | 'superadmin'
}

export function useDocuments(currentUser: CurrentUser | null) {
  const [documents, setDocuments] = useState<AcademyDocument[]>([])
  const [loading,   setLoading]   = useState(true)
  const [error,     setError]     = useState<string | null>(null)

  useEffect(() => {
    if (!currentUser?.id) return

    const load = async () => {
      setLoading(true)
      setError(null)

      // Join con profiles para obtener username y role del que subió
      const { data, error: err } = await supabase
        .from('academy_documents')
        .select(`
          id,
          category,
          title,
          url,
          file_size,
          created_at,
          alumno_id,
          uploaded_by,
          uploader:profiles!academy_documents_uploaded_by_fkey (
            username,
            role
          )
        `)
        .order('created_at', { ascending: false })

      if (err) {
        setError('No se pudieron cargar los documentos')
        setLoading(false)
        return
      }

      const docs = (data ?? []).map((d: any) => ({
        id:            d.id,
        category:      d.category,
        title:         d.title,
        url:           d.url,
        file_size:     d.file_size,
        created_at:    d.created_at,
        alumno_id:     d.alumno_id,
        uploaded_by:   d.uploaded_by,
        uploader_name: d.uploader?.username ?? null,
        uploader_role: d.uploader?.role     ?? null,
      })) as AcademyDocument[]

      setDocuments(docs)
      setLoading(false)
    }

    load()
  }, [currentUser?.id])

  const byCategory = (cat: AcademyDocument['category']) =>
    documents.filter(d => d.category === cat)

  return { documents, byCategory, loading, error }
}